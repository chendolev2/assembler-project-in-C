/*this file was made by Itay Markovitz and Chen Dolev*/
#include "main.h"
#include "macro.h"


/*the postfix for the files after spreading the macros*/
#define AFTER_MACRO_POST (".am")
#define ASM_POST (".as")
#define CHAR_ADD_NO_POST '\0'

/*create new strcut for each file, that is being read.
get:
file_name- the name of the file currnetly handled.
return pointer to the new struct created.*/
Main_file * create_main_file_struct(char *file_name);

/*freeing the main_file struct.
get:
struct_to_free-pointer to the struct to free.
return nothing(void).*/
void free_struct_main_file(Main_file *struct_to_free);


int main(int argc, char *argv[]){
	int result_macro;
	/*file_struct hold the current information about the file in the process of the assembler*/
	Main_file *file_struct;
	char *name_before_am, *name_after_am;
	/*if no file was recieved*/
	if(argc < 2){
		fprintf(stderr, "No files names were received, exiting the program\n");
		return 0;
	}
	/*go through all the file names*/
	while(argc > 1){
		argc--;
		argv++;
		/*getting the name of the file, adding postfix as needed*/
		if(create_file_name(&name_before_am, *argv, CHAR_ADD_NO_POST ,ASM_POST) == BAD_VALUE){
			fprintf(stderr, "Continue to the next file\n");
			continue;
		}
		if(create_file_name(&name_after_am, *argv, CHAR_ADD_NO_POST ,AFTER_MACRO_POST) == BAD_VALUE){
			fprintf(stderr, "Continue to the next file\n");
			free(name_before_am);
			continue;
		}
		
		/*if BAD_VALUE or EMPTY_FILE, the function doesn't create output files*/
		if((result_macro = spread_macro_func(name_before_am, name_after_am))==BAD_VALUE || (result_macro==EMPTY_FILE)){
			if(result_macro == BAD_VALUE)
				fprintf(stderr, "Can't make the file requested: %s\n\n", name_after_am);
			free(name_before_am);
			free(name_after_am);
			continue;
		}
		
		/*no need no more for the original name of the file*/
		free(name_before_am);
		file_struct = create_main_file_struct(name_after_am);
		if(file_struct == NULL){
			free(name_after_am);
			continue;
		}
		
		/*the first round module to run on the ".am" file*/
		first_round(file_struct);
		
		/*to run over the data collected and make files, then print the info into them*/
		second_round(file_struct);
	
		if(file_struct->is_valid_file == NOT_VALID_FILE)
			/*print the name of the file in case of errors*/
			fprintf(stderr, "The errors above was found in the file: %s\n\n", file_struct->file_name);
					
		/*at the end of processing a file, free the data to make space for a new one*/
		free_struct_main_file(file_struct);
		free(name_after_am);
		
	}
	return 0;
}


Main_file * create_main_file_struct(char *file_name){
	int i;

	Main_file *new_struct;
	/*geting space for the struct of Main_file*/
	new_struct = (Main_file *)malloc(sizeof(Main_file));
	if(!new_struct){
		fprintf(stderr, "Cannot get space for Main_file_struct, continue to next file\n");
		return NULL;
	}
	
	new_struct->IC = START_INDEX_IC;
	new_struct->DC = START_INDEX_DC;
	/*initializing the arrays with 0*/
	for(i = START_INDEX_IC; i < MEMORY_SIZE_MAX; i++){
		new_struct->instructions[i].val_bit.value = 0;
	}
	for(i = START_INDEX_DC; i < MEMORY_SIZE_MAX; i++){
		new_struct->data[i].val_bit.value = 0;
	}
	
	/*getting place for the name of the file to process*/
	new_struct->file_name = (char *)malloc(sizeof(char) * (1 + strlen(file_name)));
	if(new_struct->file_name == NULL){
		fprintf(stderr,"Can't get space for the name of the file in Main_file_struct, continue to next file\n");
		fprintf(stderr, "File name: %s\n", file_name);
		free(new_struct);
		return NULL;
	}
	strcpy(new_struct->file_name, file_name);
	
	/*function of trie data structure*/
	new_struct->symbols_root = create_node(' ');
	if(new_struct->symbols_root == NULL){
		fprintf(stderr, "Cannot get space for the head of symbols table in main_struct\n");
		free(new_struct->file_name);
		free(new_struct);
		return NULL;
	}

	new_struct->head_label_in_use = NULL;
	new_struct->head_entries_declared = NULL;
	new_struct->head_data_string = NULL;
	new_struct->is_valid_file = VALID_FILE;
	new_struct->is_memory_leak = NO_MEMORY_LEAK;
	return new_struct;
}


void free_struct_main_file(Main_file *struct_to_free){
	/*freeing the linked list of labels_in_use*/
	free_list_labels_used(&struct_to_free->head_label_in_use);
	/*freeing the symbols table*/
	free_trie(struct_to_free->symbols_root);
	/*freeing the labels that was declared as ".entry label", in the linked list*/
	free_entries_list(&struct_to_free->head_entries_declared);
	free_data_string_list(&struct_to_free->head_data_string);
	free(struct_to_free->file_name);
	free(struct_to_free);
}

