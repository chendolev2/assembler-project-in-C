/*this file was made by Itay Markovitz and Chen Dolev*/
#ifndef LABELS_HANDLE_H
#define LABELS_HANDLE_H

/* label's status */
#define INTERNAL_LABEL 1  /* relocatable, was deifned in the current file */
#define EXTERNAL_LABEL 0  /* label was defined in another file and was declared in this current file */

#define LABEL_EXISTS 1  /* valid label was defined in current line */
#define NO_LABEL 0  /* no valid label was defined */
#define LABEL_DEF_ILLEGAL -1 /* illegal definition of label */
#define INSERTION_LABEL_SUCCESS 1 /* label was inserted successfully to the trie/labels struct */
#define INSERTION_LABEL_FAILURE 0 /* failed to insert a label into the trie/labels struct */


/*for the labels that got declare: ".entry LABEL".*/
typedef struct entries_declared{
	char *name_declared;
	int line_number;
	struct entries_declared *next_entry;
} Entries_declared;

/*for the labels that were found in the instructions code*/
typedef struct labels_in_use{
	/*binary_address -binary line - right column*/
	int binary_address;
	/*line_address- address IMPORTANT: IC + DC + START_ADDRESS, PLEASE NOT FORGET- left column*/
	int line_number;
	char *name;
	struct labels_in_use *next;
} Labels_in_use;

/*for the data and string-to add the end IC in the symbols table*/
typedef struct data_str_insert_IC{
	char *name;
	struct data_str_insert_IC *next;
} Data_str_insert_IC;

/*to create new link of entries_declared struct and add it to the end of the list*/
int create_link_entry(Entries_declared **head_list_entries, char *label_name, int line_number);
/*freeing the linked list of entries_declared structs*/
void free_entries_list(Entries_declared **head_list);

/*create and adding new link of labels_in_use struct to a link*/
int create_link_label_in_use(Labels_in_use **link_label, char *name_label, int line_num, int binary_address);
/*freeing the linked list of a labels_in_use structs*/
void free_list_labels_used(Labels_in_use **head_label);

/*create and add new links to the data-string linked list*/
int add_new_link_data_string(Data_str_insert_IC **head_list, char *name);
/*freeing the linked list data-string*/
void free_data_string_list(Data_str_insert_IC **head_list);

#endif


