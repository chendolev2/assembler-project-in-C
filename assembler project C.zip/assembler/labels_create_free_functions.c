/*this file was made by Itay Markovitz and Chen Dolev*/
#include "libraries_c.h"
#include "labels_handle.h"

/*create link in the linked list of labels in use, adding it to the last one that was created.
get:
link_label-pointer to pointer of the Labels_in_use struct.
name_label-the name of the label used.
line_num-the current line in the file. for error printing if found later.
binary_address-the IC from main_file, to put later the address of the label there.
return BAD_VALUE if an error occured in the procces,else 0.*/ 
int create_link_label_in_use(Labels_in_use **link_label, char *name_label, int line_num, int binary_address){
	Labels_in_use *temp;
	/*checking if there is already a link in the list*/
	if(*link_label != NULL){
		temp = *link_label;
		/*finding the last link*/
		while(temp->next){
			temp = temp->next;
		}
		/*getting space for new link*/
		temp->next = (Labels_in_use *)malloc(sizeof(Labels_in_use));
		if(!(temp->next)){
			fprintf(stderr, "Can't get space for link of Labels_in_use, label: %s, line: %d\n", name_label, line_num);
			return BAD_VALUE;
		}
		temp = temp->next;
	}
	/*if it is the first link*/
	else{
		/*getting space for a new link*/
		*link_label = (Labels_in_use *)malloc(sizeof(Labels_in_use));
		if(!(*link_label)){
			fprintf(stderr, "Can't get space for link of Labels_in_use, label: %s, line: %d\n", name_label, line_num);
			return BAD_VALUE;
		}
		temp = *link_label;
	}

	/*getting space for the name*/
	temp->name = (char *)calloc(strlen(name_label) +1, sizeof(char));
	if(!(temp->name)){
		fprintf(stderr, "Can't get space for the name of the link of Label_in_use, label: %s, line: %d\n", name_label, line_num);
		free(temp);
		return BAD_VALUE;
	}

	/*copying the name to the new space*/
	strcpy(temp->name, name_label);
	
	/*inserting the varios parameters*/
	temp->binary_address = binary_address;
	temp->line_number = line_num;
	temp->next = NULL;
	
	return 0;
}

/*free the linked list of Labels_in_use.
get:
head_label- pointer to pointer to the start link for the list.
return void.*/
void free_list_labels_used(Labels_in_use **head_label){
	Labels_in_use *current, *next_link;
	next_link  = *head_label;
	while(next_link){
		current = next_link;
		next_link = next_link->next;
		free(current->name);
		free(current);
	}
	return;
}

/*checking if the label was already declared as entry.
get:
head_list- the head of the list to search the label in.
label_name- the name of the new label to check if already exist.
return BAD_VALUE, if the name is in the list, else 0.*/ 
int check_labels_declared_already(Entries_declared *head_list, char *label_name){
	Entries_declared *temp = head_list;
	while(temp != NULL){
		/*found a link in the list that already have this name*/
		if(strcmp(temp->name_declared, label_name) == 0){
			return BAD_VALUE;
		} else {
			temp = temp->next_entry;
		}
	}

	if(temp == NULL)
		return 0;
	else
		return BAD_VALUE;
}

/*create new links for the linked list- Entries_declared.
get:
entry_list_head- pointer to pointer of Entries_declared.
label_name-the name to insert.
line_number- the line of the file, that the laebl was found.
return BAD_VALUE if cannot make the new link, else return 0.*/
int create_link_entry(Entries_declared **head_list_entries, char *label_name, int line_number){
	Entries_declared *next;
	
	/*if there already links*/
	if(*head_list_entries != NULL){
		if(check_labels_declared_already(*head_list_entries, label_name) == BAD_VALUE){
			fprintf(stderr, "Label: %s, was declared more than once, (again at)line: %d\n", label_name, line_number);
			return BAD_VALUE;
		}
		next = *head_list_entries;
		/*loop through the list*/
		while(next->next_entry){
			next = next->next_entry;
		}
		next->next_entry = (Entries_declared *)malloc(sizeof(Entries_declared));
		/*if can't get space*/
		if(!(next->next_entry)){
			fprintf(stderr, "Cannot get space for link of entries struct, label: %s, line: %d\n", label_name ,line_number);
			return BAD_VALUE;
		}
		/*next pointing to the last link that created*/
		next = next->next_entry;
	}
	/*if this is the head of the list and it is empty*/
	else{
		*head_list_entries = (Entries_declared *)malloc(sizeof(Entries_declared));
		/*error in getting space*/
		if(!(*head_list_entries)){
			fprintf(stderr, "Cannot get space for link of entries struct, label: %s, line: %d\n", label_name ,line_number);
			return BAD_VALUE;
		}
		next = *head_list_entries;
	}
	
	/*adding space for the name of the label, for the new link*/
	next->name_declared = (char *)calloc((1 + strlen(label_name)) , sizeof(char));
	if(!(next->name_declared)){
		fprintf(stderr, "Cannot get space for the name of the entry label: %s, line: %d\n", label_name, line_number);
		free(next);
		return BAD_VALUE;
	}
	
	/*copying the name of the label*/
	strcpy(next->name_declared, label_name);
	next->line_number = line_number;
	next->next_entry = NULL;
	return 0;
}

/*freeing the linked list of the entries struct.
get:
head_list- pointer to pointer of the head of the list.
return void.*/
void free_entries_list(Entries_declared **head_list){
	Entries_declared *current, *next;
	next = *head_list;
	/*going with loop on all the list and freeing the name and the link itself*/
	while(next){
		current = next;
		next = next->next_entry;
		free(current->name_declared);
		free(current);
	}
}

/*create and add new links to the data-string list.
get:
head_list the head of the linked list data_string_insert_IC.
name- the name to insert into the new link.
return BAD_VALUE if can't get space, else 0.*/
int add_new_link_data_string(Data_str_insert_IC **head_list, char *name){
	Data_str_insert_IC *temp;
	/*if the list is empty*/
	if(*head_list == NULL){
		/*getting spcae for the new link*/
		*head_list = (Data_str_insert_IC *)malloc(sizeof(Data_str_insert_IC));
		if(*head_list == NULL){
			fprintf(stderr, "Cannot get space for link in Data_str list, name:%s\n", name);
			return BAD_VALUE;
		}
		temp = *head_list;
	} else {
		/*going to the last link*/
		temp = *head_list;
		while(temp->next){
			temp = temp->next;
		}
		/*getting space for the new link*/
		temp->next = (Data_str_insert_IC *)malloc(sizeof(Data_str_insert_IC));
		if(temp->next == NULL){
			fprintf(stderr, "Cannot get space for link in Data_str list, name:%s\n", name);
			return BAD_VALUE;
		}
		temp = temp->next;
	}
	
	/*getting and adding the name of the label to the link*/
	temp->name = (char *)calloc(sizeof(char), strlen(name) + 1);
	if(temp->name == NULL){
		fprintf(stderr, "Cannot get space for name of link in data-string list, name:%s\n", name);
		free(temp);
		return BAD_VALUE;
	}
	
	strcpy(temp->name, name);
	temp->next = NULL;
	return 0;
}



/*freeing the linked list of the data_string struct.
get:
head_list- pointer to pointer of the head of the list.
return void.*/
void free_data_string_list(Data_str_insert_IC **head_list){
	Data_str_insert_IC *current, *next;
	next = *head_list;
	/*going with loop on all the list and freeing the name and the link itself*/
	while(next){
		current = next;
		next = next->next;
		free(current->name);
		free(current);
	}
}


