/*this file was made by Itay Markovitz and Chen Dolev*/
#include "syntax.h" 
/*This program analyses instruction sentences and updates file_status and data accordingly (file_struct). 
	In case the instruction is valid and there is no memory leak, the program codes its operation and parameters values */


/* check validation of register parameter and - register parameter is a valid number between 0 to REGISTER_NUM-1  
	PARAMETERS: param = register parameter, param_num_value = number of valid register,
	 	file_struct = file's data and status, line_num = number of row in am file
	return REG if parameter is valid register, ILLEGAL_PARAM otherwise */
char register_param_validation(char* param, int *param_num_value, Main_file* file_struct, int line_num) {
	int register_num;

	if (is_integer(param + 2)) { /* number after '@r' */
		register_num = atoi(param + 2);
		if (register_num >= 0 && register_num <= (REGISTER_NUM - 1)) {
		    *param_num_value = register_num;
			return REG;  /* parameter is valid label */	
		}
	} 
		
	 /* update error message - invalid register  */
	 fprintf(stderr, "Invalid parameter - register name of '@r' should be a number "\
	 "between 0 to %d, line: %d\n", REGISTER_NUM - 1, line_num);
	 file_struct -> is_valid_file = NOT_VALID_FILE;
	return ILLEGAL_PARAM;
}


/* check type of current parameter - NUM/REG/LABEL/ILLEGAL_PARAM
	NUM - valid number between MIN_NUM_10 to MAX_NUM_10, REG = register with valid name between 0 to REGISTER_NUM-1,
	LABEL - valid label (according to label properties), ILLEGAL_PARAM - parameter wasn't recognized 
	PARAMETERS: param = current parameter, param_num_value = value of valid number/register number,
	 	file_struct = file's data and status, invalid_name_label = list of saved words forbidden for labels
	 	line_num = number of row in am file
	return NUM/REG/LABEL if parameter is valid, ILLEGAL_PARAM otherwise */
int type_of_parameter(char *param, int *param_num_value, Main_file* file_struct, char** invalid_name_label, int line_num) {
	int param_length = (int)strlen(param); 
	/* check if parameter is a number */
	if (param[0] == '+' || param[0] == '-' || isdigit(param[0]))  {
		/* check if parameter is valid. NUM:valid number, ILLEGAL_PARAM:otherwise */
		return num_param_validation(param, param_num_value, file_struct, line_num, MIN_NUM_10, MAX_NUM_10);

	/* check if parameter is a register */
	} else if (param[0] == '@' && param[1] == 'r') { 
		/* check if register is valid. REG:valid register, ILLEGAL_PARAM:otherwise */
		return register_param_validation(param, param_num_value, file_struct, line_num);

	/* check if parameter is label - existence will be checked later*/	
	} else if (isalpha(param[0]))  { /* labels starts with a letter */
		if (is_valid_label_exists(param, file_struct, param_length, invalid_name_label, line_num) == LABEL_EXISTS) {
			return LABEL;
		} else
			return ILLEGAL_PARAM;
	} else {	
		if (strcmp(param, " ") == 0 || strcmp(param, "") == 0)  {
			fprintf(stderr, "Parameter with no value is invalid, line: %d\n", line_num);
		} else {
			fprintf(stderr, "Unknown type of parameter - '%s', line: %d\n", param, line_num);
		}
		file_struct -> is_valid_file = NOT_VALID_FILE;
		return ILLEGAL_PARAM; /* unknown parameter */
	}	
}


/* check for match between the type of current parameter and its operation, depends if the parameter is source/target
	each operation can get only certain types as source or target.
	The data of each operation and its parameters is taken from common_data file - 'operations' array.
	PARAMETERS: opcode_ind = unique number for each operation, parameter_type = NUM/REG/LABEL,
	 	file_struct = file's data and status, is_source = 1 if parameter is source 0 if parameter is target 
		operations = a pointer to an array with all operations and the parameters types each operation can get as source/target 
	 	line_num = number of row in am file
	return BAD_PARAM for mismatch, GOOD_PARAM otherwise */
int param_type_match_oper(int opcode_ind, int parameter_type, Main_file* file_struct,\
									int is_source, struct operation_data* operations, int line_num) {
	int index = 0;
	int current_value;
	
	if (is_source && operations[opcode_ind].param_number != 1) { /* parameter is source */
		while ((current_value = operations[opcode_ind].source[index]) != END_ARR) {
			if (current_value == parameter_type) {  /*type of parameter is valid option for source*/
				return GOOD_PARAM;
			}
			index ++;
		}
		
	fprintf(stderr, "Source parameter for operation '%s' can't be %s, line: %d\n",\
	operations[opcode_ind].opcode_name, parameter_type == NUM? "number":\
	(parameter_type == LABEL? "label": "register"), line_num);
	file_struct -> is_valid_file = NOT_VALID_FILE;	
	return BAD_PARAM;
	
	
	} else {  /* parameter is target */
		while ((current_value = operations[opcode_ind].target[index]) != END_ARR) {
			if (current_value == parameter_type) {  /*type of parameter is valid option for target*/
				return GOOD_PARAM;
			} 
			index ++;
		}

	fprintf(stderr, "Target parameter for operation '%s' can't be %s, line: %d\n",\
	operations[opcode_ind].opcode_name, parameter_type == NUM? "number":\
	(parameter_type == LABEL? "label": "register"), line_num);
	file_struct -> is_valid_file = NOT_VALID_FILE;	
	return BAD_PARAM;	
	}
}


/* check the current parameter - its type, is it matches the operation and its value.
	If there is no memory leak and the parameter is valid, its value is coded (in case of number or register).
	In case of valid label, the label is inserted to head_label_in_use linked list and will be coded later on the second round.
	PARAMETERS: line = instruction definition, label = (of current instruction) not a must, opcode_ind =  unique number for each operation,
	 	is_source = 1 if parameter is source 0 if parameter is target, file_struct = file's data and status, line num = number
	 	of the row in am file, is_prev_param_register = 1 if the previous parameter is register, param_num = overall number of parameters,
		operations = a pointer to an array with all operations and the parameters types each operation can get as source/target 
		invalid_name_label = list for saved words forbidden for labels 
	return BAD_PARAM for invalid parameter, GOOD_PARAM otherwise */
int evaluate_inst_parameter(char** line, char* label, int opcode_ind, int is_source, Main_file* file_struct,\
			int line_num, int* is_prev_param_register, int param_num, struct operation_data* operations, char** invalid_name_label) {	
			
	int binary_address = file_struct -> IC + START_ADDRESS; /* address of the binary code representation */			
	char param[MAX_LINE_LENGTH] = {0};  /* labels are the parameters with biggest size*/
	int j, DC = file_struct -> DC;
	int parameter_type; /* label=3/register=5/number=1/illegal parameter=-1 */
	int parameter_match_operation;  /* = BAD_PARAM is there is a mismatch, GOOD_PARAM otherwise */
	int param_num_value; /* register number or value of number variable. if type=label->no change */

	/* reads parameter from line */
	for(j = 0; **line != ',' && **line != '\n' && **line != '\0'; j++) {
		param[j] = **line; 
		(*line)++;
	}
	param[j] = '\0';
	erase_extra_spaces(param);  /* erase extra spaces from the parameter */
	
	parameter_type = type_of_parameter(param, &param_num_value, file_struct, invalid_name_label, line_num);
    if (parameter_type == ILLEGAL_PARAM) { /* invalid type of parameter */
    	return BAD_PARAM;
    }
    
    /* checks if type of parameter is valid for the current operation */
	parameter_match_operation = param_type_match_oper(opcode_ind, parameter_type, file_struct, is_source, operations, line_num);
	if (parameter_match_operation == BAD_PARAM) { /* type doesn't match for operation */
    	return BAD_PARAM;
	}
	
	if (parameter_type == NUM)	{
		/* update the binary code */
		if (is_source) {
			file_struct->instructions[file_struct->IC-1].inst_ln.source = NUM;
		} else if (!is_source && param_num == 1) {
			file_struct->instructions[file_struct->IC-1].inst_ln.target = NUM;
		} else {  /* param_num == 2 */
			file_struct->instructions[file_struct->IC-2].inst_ln.target = NUM;
		}
		if (file_struct -> is_memory_leak == NO_MEMORY_LEAK && is_memory_leak(file_struct->IC, DC, file_struct, line_num)== NO_MEMORY_LEAK) {  
		/* enough memory space for encoding */
			file_struct->instructions[file_struct->IC].const_num.ARE = 0;
			file_struct->instructions[file_struct->IC].const_num.num = param_num_value;
			file_struct->IC = file_struct->IC + 1; /* promotes the counter to the next available position */	
		}
	} else if (parameter_type == REG) {
	
		if (*is_prev_param_register == 1) {
			/* codes the second register on same row as the first parameter */
			file_struct->instructions[file_struct->IC - 1].reg_reg.target = param_num_value;
			file_struct->instructions[file_struct->IC - 1].reg_reg.ARE = 0;
			file_struct->instructions[file_struct->IC - 2].inst_ln.target = REG;
			file_struct->IC = file_struct->IC -1;
		} else {
/* Its the first parameter or the previous parameter was number/label -> new row for binary code*/
			if (is_source) {
				file_struct->instructions[file_struct->IC-1].inst_ln.source = REG;
			} else if (!is_source && param_num == 1) {
				file_struct->instructions[file_struct->IC-1].inst_ln.target = REG;	
			} else {
				file_struct->instructions[file_struct->IC-2].inst_ln.target = REG;
				}
			}
			if (file_struct -> is_memory_leak == NO_MEMORY_LEAK && is_memory_leak(file_struct->IC, DC, file_struct, line_num)==NO_MEMORY_LEAK) { 
			 /* enough memory space for encoding */
				/* updates the binary code of the register variable */
				file_struct->instructions[file_struct->IC].reg_reg.ARE = 0;
				if (is_source) {
					file_struct->instructions[file_struct->IC].reg_reg.source = param_num_value;
				} else {   /* variable is target */
					file_struct->instructions[file_struct->IC].reg_reg.target = param_num_value;
					if(param_num == 1){
						file_struct->instructions[file_struct->IC].reg_reg.source = 0;
					}
				}
				file_struct->IC = file_struct->IC + 1; /* promotes the counter to the next available position */	
				/* update for the next parameter that the last one was register */
				*is_prev_param_register = 1; 
			}
		} else if (parameter_type == LABEL) {
			if (is_source) {
				file_struct->instructions[file_struct->IC-1].inst_ln.source = LABEL;
			} else if (!is_source && param_num == 1) {
				file_struct->instructions[file_struct->IC-1].inst_ln.target = LABEL;	
			} else {
				file_struct->instructions[file_struct->IC-2].inst_ln.target = LABEL;
				}
			
			if (file_struct -> is_memory_leak == NO_MEMORY_LEAK && is_memory_leak(file_struct->IC, DC, file_struct, line_num) == NO_MEMORY_LEAK) {
			 /* enough memory space for encoding */
			/* add current label to labels_in_use list for coding it on the second round */
				if (create_link_label_in_use(&(file_struct -> head_label_in_use), param, line_num, binary_address) == BAD_VALUE) {
					file_struct -> is_valid_file = NOT_VALID_FILE;
					return BAD_PARAM;
				}
			file_struct->IC = file_struct-> IC + 1; /* promotes the counter to the next available position */	
			}
	}

	return GOOD_PARAM;
}


/* check if instruction line is valid - valid operation, valid parameters that match the operation, no invalid commas.
	the function checks if a label was defined, if the label is valid and doesn't exists in the symbols table, the label is inserted 
	If there is no memory leak and the parameters are valid, the opcode and its parameters are coded. Check for extra characters (error).
	PARAMETERS: line = instruction definition, label = (of current instruction) not a must, file_struct = file's data and status,
		operations = a pointer to an array with all operations and the parameters types each operation can get as source/target 
		invalid_name_label = list for saved words forbidden for labels, line_num = number of row in the am file  
	return VALID_FILE if instruction line is valid, NOT_VALID_FILE otherwise */
int is_instruction_valid(char* line, char* label, Main_file* file_struct,\
				 struct operation_data* operations, char** invalid_name_label, int line_num) {
    char operation[MAX_LINE_LENGTH] = {0}; /* operation name */
    int i, j, operation_ind; /* operation index in the operations table = its binary number */
    int is_prev_param_register = 0;  /* =1 if the previous checked parameter is register */
    int is_source = 1;  /* marks the current evaluated parameter as source or target */
    int param_num;  /* the valid parameters number of the operation */
    int param_status; /* =GOOD_PARAM if param is legal and matches the function, BAD_PARAM otherwise */
    char* line_helper;
    int parameter_counter = 0;  /* counts how many parameters were typed for current instruction */
    int length = strlen(line); 
	int comma_status = NO_MISSING_COMMA;
	int label_exist = NO_LABEL;
	int start_ic = file_struct->IC, start_dc = file_struct-> DC;
	
    if ((label_exist = is_label_def_exists(line, label, file_struct, invalid_name_label, line_num)) == LABEL_DEF_ILLEGAL) { /* illegal label definition */
    	return NOT_VALID_FILE;
    }
		
	if (line[0] == ',' || (line[length-1] == '\n' && line[length-2] == ',') || (line[length -1] == ',')) {  /* definition ends with invalid comma */
	fprintf(stderr, "Invalid comma at the %s of the line, line: %d\n", line[0] == ','? "begining":"end", line_num);
	file_struct -> is_valid_file = NOT_VALID_FILE;
	return NOT_VALID_FILE; 
	}
	
	/* promotes pointer to the character after the column and space */
	if (strchr(line, ':') != NULL) {
		for (; *line != ':'; line++);  line++; 
		for (; isspace(*line); line++);
	}  
  
    /* check if operation name is valid */
    for(j = 0; *line != ' ' && *line != '\0' && *line != '\n' && *line != ',';) {
		operation[j++] = *line++;  /* copies current operation to 'operation name */
    }
    if (*line == ',') {
	if(strlen(operation) >= 1){
    		fprintf(stderr, "Illegal comma at the end of operation: '%s', line: %d\n",operation, line_num);
	} else{
		fprintf(stderr, "Missing operation, line: %d\n", line_num);
	}
    	file_struct -> is_valid_file = NOT_VALID_FILE;
    	return NOT_VALID_FILE;
    }
    operation[j] = '\0';
	
	/* search in the operations table if the current operation is valid */
    for (i = 0; i < OPERATION_NUM; i++) {
        if (strcmp(operation, operations[i].opcode_name) == 0) {
        	operation_ind = i;
			if (file_struct -> is_memory_leak == NO_MEMORY_LEAK && is_memory_leak(file_struct->IC, file_struct->DC, file_struct, line_num)== NO_MEMORY_LEAK) { /* enough memory space for encoding */
        	/* updates the binary code */
		    	file_struct->instructions[file_struct->IC].inst_ln.opcode = i;
		    	file_struct->instructions[file_struct->IC].inst_ln.target = 0;
		    	file_struct->instructions[file_struct->IC].inst_ln.source = 0;
		    	file_struct->instructions[file_struct->IC].inst_ln.pad = 0;  
		    	file_struct->IC = file_struct->IC + 1; /* promotes the counter to the next available position */   
		     }
			 break; /* found matching legal operation */			 
        }
    }

    if (i == OPERATION_NUM)  {  /* the current operation illegal */
    	fprintf(stderr, "Illegal operation name: %s, line: %d\n", operation, line_num);
    	file_struct -> is_valid_file = NOT_VALID_FILE;
    	return NOT_VALID_FILE;
	} 
	
	line_helper = line;
	/* analyze parameters */
	param_num = operations[operation_ind].param_number; 
	if (param_num == 1)  { /* the operand is target, marks as target */
		is_source = 0;
	}
	
	/* check number of parameters, search for missing comma/invalid space */
	erase_extra_spaces(line_helper);
	is_missing_comma_parameters(line_helper, &parameter_counter, &comma_status, line_num);

	if (parameter_counter == param_num && comma_status == MISSING_COMMA) {
		fprintf(stderr, "Illegal space in parameter or extraneous text at the end of the line, line: %d\n", line_num);
		file_struct -> is_valid_file = NOT_VALID_FILE;
    	return NOT_VALID_FILE;
	} else if (parameter_counter < param_num) {
		fprintf(stderr, "There is a missing comma/too few parameters were accepted for operation '%s'. "\
		"Expected to get %d %s and got %d %s, line: %d\n", operation, param_num,\
		 param_num == 1? "parameter": "parameters", parameter_counter, parameter_counter == 1? "parameter": "parameters",line_num);
		file_struct -> is_valid_file = NOT_VALID_FILE;
    	return NOT_VALID_FILE;
	} else if (parameter_counter > param_num) {
		fprintf(stderr, "Too many parameters for operation '%s'. Expected to get %d %s, line: %d\n", operation,\
	     param_num, param_num == 1? "parameter": "parameters", line_num);
	    file_struct -> is_valid_file = NOT_VALID_FILE;
    	return NOT_VALID_FILE; 
	}	
		
	if (operations[i].param_number != 0)  {  /* at least one parameter is required */
		
		if (*line == ',') {
			fprintf(stderr, "Illegal comma between the operation and its parameters, line: %d\n", line_num);
    		file_struct -> is_valid_file = NOT_VALID_FILE;
    		return NOT_VALID_FILE;
    	}
		/* evaluate the first parameter */	  
		param_status = evaluate_inst_parameter(&line, label, i, is_source, file_struct, line_num, &is_prev_param_register,\
					 param_num, operations, invalid_name_label);

		for (; isspace(*line) ; line++); 
		if (param_status == BAD_PARAM)  {
    		return NOT_VALID_FILE; 
   		}		 
			
		if (param_num == 2) {
			/* evaluate the second parameter */
			is_source = 0;  /* marks the current parameter as target */
			line++; /* skips ',' character */	
			erase_extra_spaces(line);
			param_status = evaluate_inst_parameter(&line, label, i, is_source, file_struct, line_num, &is_prev_param_register, \
					param_num, operations, invalid_name_label);

			if (param_status == BAD_PARAM)  {
    			return NOT_VALID_FILE; 
    			}
		}
	}
	if(label_exist == LABEL_EXISTS){
		if(insert_label_if_new(line, label, file_struct, line_num, INTERNAL_LABEL, start_ic, start_dc, INSTRUCTION) == INSERTION_LABEL_FAILURE){
		return NOT_VALID_FILE;
		}
	}
	return 	VALID_FILE;
}



