/*this file was made by Itay Markovitz and Chen Dolev*/
#ifndef MACRO_H
#define MACRO_H

#include <ctype.h>
#define EMPTY_FILE -3
int spread_macro_func(char *file_name_read, char *file_name_write);

#endif
