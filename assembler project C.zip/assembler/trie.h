/*this file was made by Itay Markovitz and Chen Dolev*/
#ifndef TRIE_H
#define TRIE_H 

#define CHARS 62 /* 26 lowercase + 26 uppercase + 10 digits */
#define ENGLISH_UPPER 26 /* uppercase letters */
#define ENGLISH_UPPER_LOWER 52 /* 26 uppercase + 26 lowercase */ 
#define FOUND 1
#define NOT_FOUND 0

/* define trienode structure for saving labels */
typedef struct trienode {
	char character; 
	int end_of_word; /* 1 for ending of a valid word */
	struct trienode** children;
	
	/* data - is saved in the last node that represents the label */
	int binary_address; /* address of the binary code representation */
	int internal; /* 1 if internal label, 0 if external label, 2 for instruction label */
} Trienode;


/* create new trienode */
Trienode* create_node(char character);

/* insert a new label into the trie */
void insert_label(Trienode **root, char *label, int binary_address, int internal);

/* check if the current label was already inserted into trie */
int is_label_saved(Trienode *root, char *label, int *binary_address, int *internal, int IC_to_add);

/* free all the allocated memory for the label's trie */
void free_trie(Trienode *node);


#endif 


