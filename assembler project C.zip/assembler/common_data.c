/*this file was made by Itay Markovitz and Chen Dolev*/
#include "common_data.h"

/* This file contains 2 functions that each one of them returns an array
	- get_operations_array returns the array with all the opcode names
	 (instructions), number of parameters for each opcode and valid types for source and
	 target parameter 
	- get_invalid_name_label_array returns all saved words in the computer that can't be used
	as label's name - opcode names and directive types */
	

/* initialize and return the 'operations' array */
struct operation_data* get_operations_array() {
    static struct operation_data operations[OPERATION_NUM] = {
/* opcode name, param number, valid source, valid target */
	{"mov", 2, {NUM,LABEL,REG, END_ARR}, {LABEL, REG, END_ARR}},
	{"cmp", 2, {NUM,LABEL,REG, END_ARR}, {NUM, LABEL, REG, END_ARR}},
	{"add", 2, {NUM,LABEL,REG, END_ARR}, {LABEL, REG, END_ARR}},
	{"sub", 2, {NUM,LABEL,REG, END_ARR}, {LABEL, REG, END_ARR}},
	{"not", 1, {END_ARR}, {LABEL, REG, END_ARR}},
	{"clr", 1, {END_ARR}, {LABEL, REG, END_ARR}},
	{"lea", 2, {LABEL, END_ARR}, {LABEL, REG, END_ARR}},
	{"inc", 1, {END_ARR}, {LABEL, REG, END_ARR}},
	{"dec", 1, {END_ARR}, {LABEL, REG, END_ARR}}, 
	{"jmp", 1, {END_ARR}, {LABEL, REG, END_ARR}},
	{"bne", 1, {END_ARR}, {LABEL, REG, END_ARR}},
	{"red", 1, {END_ARR}, {LABEL, REG, END_ARR}},
	{"prn", 1, {END_ARR}, {NUM,LABEL, REG, END_ARR}}, 
	{"jsr", 1, {END_ARR}, {LABEL, REG, END_ARR}}, 
	{"rts", 0, {END_ARR}, {END_ARR}},  
	{"stop",0, {END_ARR}, {END_ARR}}     
    };
    return operations;
}

/* initialize and return the 'invalid_name_label' array */
char** get_invalid_name_label_array() {
    static char* invalid_name_label[SAVED_NAMES] = {
       "mov", "cmp", "add", "sub", "not", "clr", "lea", "inc", "dec", "jmp", "bne",
       "red", "prn", "jsr", "rts", "stop", ".data", ".string", ".extern", ".entry",
       };
    return invalid_name_label;
}


