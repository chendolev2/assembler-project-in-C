/*this file was made by Itay Markovitz and Chen Dolev*/
#include "syntax.h"
#define NL_PLUS_NULL 2

/*going through the file requsted, checking for error of syntax, memory leaks, and ect'.
inserting labels into the symbols table, and the other linked lists dedicated to them.
get:
main_file-to hold and work with the current info known and gathered from the file.
return BAD_VALUE if there was an error that was found, else 0.*/
int first_round(Main_file *main_file) {
	int ch, internal = 0, bin_add = 0, line_num = 0, return_value = 0;
	char line[MAX_LINE_LENGTH + NL_PLUS_NULL] = {'\0'};
	Data_str_insert_IC *temp;
   
	/*the file to read the info from*/
    FILE *file_ptr;
    file_ptr = fopen(main_file->file_name, "r");
    
    if (!file_ptr) {
        fprintf(stderr, "Cannot open the file: %s\n", main_file->file_name);
		main_file -> is_valid_file = NOT_VALID_FILE;
        return BAD_VALUE;
    }

	/*getting all the lines, from the file*/
    while (fgets(line, sizeof(line), file_ptr)) {
        line_num++;
		/*checking if the line is too long, if it is, reading the rest of the line*/
        if ((strlen(line) >= MAX_LINE_LENGTH + NL_PLUS_NULL - 1) && (line[MAX_LINE_LENGTH + NL_PLUS_NULL -2] != '\n')) {
            fprintf(stderr, "Line is longer than maximum valid length-%d, line:%d\n", MAX_LINE_LENGTH, line_num);
            main_file -> is_valid_file = NOT_VALID_FILE;
			fseek(file_ptr, -1, SEEK_CUR);
	    	while((ch = fgetc(file_ptr)) != '\n' && ch != EOF);
	    	if(ch == EOF)
				break;
			else
				continue;
        }
 		/*evaluating the line's content*/   	
        if (is_syntax_valid(line, main_file, line_num) == NOT_VALID_FILE) {
            return_value = BAD_VALUE;
        }
    }
	/*adding the current IC to the address of the data and string labels*/
	temp = main_file->head_data_string;
	while(temp){
    		is_label_saved(main_file->symbols_root, temp->name, &bin_add, &internal, main_file->IC);
		temp = temp->next;		
	}
    
    fclose(file_ptr);
    return return_value;
}
