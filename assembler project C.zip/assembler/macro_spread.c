/*this file was made by Itay Markovitz and Chen Dolev*/
#include "libraries_c.h"
#include "macro.h"

/*80 chars + 1 for '\n'  + 1 for '\0' + 18 for long extra long lines*/
#define LINE_LEN_MACRO 150
/*the start amount of places for chars in the macro content*/
#define START_SIZE_MACRO_CONTENT 20
/*to have smallest and biggest sizes for the macro name, max is 33 because size of label max is 31 + '\0'*/
#define NAME_MACRO_SIZE 1
#define MAX_NAME_MACRO 32
#define VALID_MACRO_NAME "valid_name"
/*to check sizes and spelling of the words*/
#define MCRO_WRD_LEN 4
#define MCRO_WRD "mcro"
#define ENDMCRO_WRD_LEN 7
#define ENDMCRO_WRD "endmcro"

/*struct to hold data on each macro, linked list
name - the name of this macro.
macro_content - the content inside this macro.
next - the next link(or NULL).*/
typedef struct macro_struct{
	char *name;
	char *macro_content;
	struct macro_struct *next;
} Macro_struct;


/*checking if in current line, it the start of defining of a macro.
get:
array- the current line to check in.
return - 0 if it is definition of macro, else BAD_VALUE*/
int is_macro_def(char *array){
	int i;
	i = 0;
	/*skipping white space*/
	while(array[i] == ' ' || array[i] == '\t'){
		i++;
	}
	/*checking if the first word is the instruction word to start defining macro, if it is return 0*/
	if(strncmp((array+i), MCRO_WRD ,MCRO_WRD_LEN) == 0){
		if(array[i + MCRO_WRD_LEN] == ' ' || array[i + MCRO_WRD_LEN] == '\t'){
			return 0;
		/*putting space to catch the no name macro in another function*/ 
		} else if(array[i + MCRO_WRD_LEN] == '\n'){
			array[i + MCRO_WRD_LEN] = ' ';
			return 0;
		} else {
			return BAD_VALUE;
		}
	}
	else{
		return BAD_VALUE;
	}
}


/*saving the content of the macro in the macro link.
get:
array- the line from file to read
curr_link- the last link in the struct of the macros
file- to read more lines till it is "endmcro"
line_num- counting the lines of the file.
head_link- to check if the name of the macro is already in the linked list.
return - 0 if the building was successfull, else BAD_VALUE*/
int build_macro(char *array, Macro_struct *curr_link, FILE *file, int *line_num, Macro_struct *head_link){
	/*size_saved_content- the amount of characters got for the content of this macro.
	amount_content- the amount of chars already in the macro-CONTENT*/ 
	int i, j,amount_content = 0,size_saved_content = START_SIZE_MACRO_CONTENT , name_already_used = !BAD_VALUE;
	/*to hold the copying name into the , temp content and temp name are to hold the addresses of macro_content of the current link and curr_link->name when they go through realloc*/	
	char *temp_content, *temp_name_struct ,name[MAX_NAME_MACRO] = {'\0'};
	/*to point to the start of the linked list*/
	Macro_struct *head_temp = head_link;
	/*invalid names for the macro tp have*/
	const char *invalid_macro_names[] = {"mov", "cmp", "add", "sub", "not", "clr", "lea", "inc", "dec", "jmp", "bne", "red", "prn", "jsr", "rts", "stop", VALID_MACRO_NAME};
	/*going through the array to pass the white space first*/
	i=0;
	while(array[i] == ' ' || array[i] == '\t'){
		i++;
	}
	/*now jumping on the "mcro" word*/
	i += MCRO_WRD_LEN;
	/*if there are white space after "mcro"*/
	while(array[i] == ' ' || array[i] == '\t'){
		i++;
	}
	if(array[i] == '\n' || array[i] == '\0'){
		fprintf(stderr, "Missing macro name, line: %d\n", *line_num);
		return BAD_VALUE;
	}
	
	/*copying the name to the array, j for the name array*/
	j = 0;
	while((j < MAX_NAME_MACRO - 1) && array[i] != ' ' &&  array[i] != '\t' && array[i] != '\n' && array[i] !='\0'){
		name[j] = array[i];
		j++;
		i++;
	}
	name[j] = '\0';

	/*if the name is too long*/
	if((j >= MAX_NAME_MACRO - 1) && array[i] != ' ' &&  array[i] != '\t' && array[i] != '\n' && array[i] !='\0'){
		fprintf(stderr, "Macro name is too long, line: %d\n", *line_num);
		return BAD_VALUE;
	}

	/*if there is only valid chars in the macro name*/
	if(isalpha(name[0])){
		for(j = 1; name[j] != '\0';j++){
			if(!isalnum(name[j])){
				fprintf(stderr,"Macro name contains illegal char, name:%s, line:%d\n", name, *line_num);
				return BAD_VALUE;
			}
		}
	} else {
		fprintf(stderr,"Macro name contains illegal first char, name:%s, line:%d\n", name, *line_num);
		return BAD_VALUE;
	}

		
	/*checking if the name of the macro is reserved for other names*/
	for(j = 0; strcmp(invalid_macro_names[j], VALID_MACRO_NAME) != 0; j++){
		if(strcmp(invalid_macro_names[j], name) == 0){
			fprintf(stderr,"Illegal name was given to macro: %s, line: %d\n", name, *line_num);
			return BAD_VALUE;
		}
	}
	/*checking if there isn't anymore chars(non-white) after the name of the macro*/
	for(;array[i] != '\n' && array[i] != '\0';i++){
		if(array[i] != ' ' && array[i] != '\t'){
			fprintf(stderr, "Extra characters after the macro name: %s, line: %d\n", name, *line_num);
			return BAD_VALUE;
		}
	}

	/*checking for a macro with this name that was declared before*/
	while(head_temp != NULL){
		if(strcmp(name, head_temp->name) == 0){
			fprintf(stderr,"Macro with name: %s, was defined more than once, line:%d\n",name,*line_num);
			name_already_used = BAD_VALUE;
			break;
		}
		head_temp = head_temp->next;
	}
	
	/*getting space for the name, fitting one*/
	temp_name_struct = (char *)realloc(curr_link->name, sizeof(char) * (strlen(name)+1));
	/*could not get the space*/
	if(temp_name_struct == NULL){
		fprintf(stderr, "Problem with getting space for a name of macro, name: %s, line: %d\n", name, *line_num);
		return BAD_VALUE;
	}
	
	curr_link->name = temp_name_struct;
	/*get the name into its final location*/
	curr_link->name = strcpy(curr_link->name, name);

	/*now we have the name of the macro saved in the struct*/
	/*in a loop, getting new lines, if they are not the end of the macro and not white space than copying them to the array*/
	while(1){
		/*getting new line*/
		fgets(array, LINE_LEN_MACRO, file);
		*line_num += 1;
		/*will read the white space, and will continue to the next line if there was only white space*/
		i = 0;
		/*skiping if it is comment*/
		if(array[i] == ';'){
			continue;
		}
		while(array[i] == ' ' || array[i] == '\t'){
			i++;
			if(array[i] == '\n'){
				break;
			}
		}
		if(array[i] == '\n')
			continue;

		/*the end of the definition of the macro*/ 
		if(strncmp((array + i), ENDMCRO_WRD, ENDMCRO_WRD_LEN) == 0){
			for(j =  i + ENDMCRO_WRD_LEN ;array[j] != '\n' && array[j] != '\0';j++){
				if(array[j] != ' ' && array[j] != '\t'){
				fprintf(stderr,"Extra characters after the \"endmcro\" word, line: %d \n", *line_num);
				fprintf(stderr, "Macro name: %s\n", name);
				return BAD_VALUE;
				}
			}
			if(name_already_used == BAD_VALUE){
				return BAD_VALUE;
			}
			return 0;
		}
		/*checking if the macro_content need more space to add new contnet*/
		if((strlen(array) + 1 + amount_content) >= (size_saved_content - amount_content)){
			temp_content = (char *)realloc(curr_link->macro_content, 2*sizeof(char)*(size_saved_content+strlen(array)));
			if(temp_content == NULL){
				fprintf(stderr,"Can't get enough space for the content of the macro, macro: %s, line: %d\n", name, *line_num);
				return BAD_VALUE;
			}
			size_saved_content = (strlen(array) + size_saved_content) * 2;
			curr_link->macro_content = temp_content;
		}
		/*copying the new line from the macro into macro_content*/ 
		curr_link->macro_content = strcat(curr_link->macro_content, array);
		/*indicating that there is more chars in the macro_content*/
		amount_content += strlen(array);
	}

	return 0;
}


/*checking if a line have macro name in it, printing the line and the macro if found.
get:
array - the current line to check.
head_link - macro_struct to check against the words, and putting the content if it is macro name.
fout - the file to write to.
return void.*/
void is_macro_name(char *array, Macro_struct *head_link, FILE *fout){
	 Macro_struct *start_link = head_link;
	/*to get the word from the line of text*/
	/*because the function get a line from the text which is length max of LINE_LEN_MACRO, than even if the 
	line is only non-white characters, it will get in the array, with no need to check for its limit*/ 
	char word_check[LINE_LEN_MACRO];
	int i, j, k = 0;
	i = 0;
	while(array[i] != '\0' && array[i] != '\n'){
		/*skiping the white space*/
		while(array[i] == ' ' || array[i] == '\t'){
			fputc(array[i], fout);
			i++;
		}
		/*deaing with the case of macro name in string*/
		if(array[i] == '\"'){
			fputc(array[i], fout);
			i++;
			/*read and print the whole string, if it's invalid string, than until the end of the line*/
			while(array[i] != '\0' && array[i] != '\n' && array[i] != '\"'){
				fputc(array[i], fout);
				i++;
			}
			/*if we reached the end of the line*/
			if(array[i] == '\n' || array[i] == '\0')
				return;
		}
		/*skiping the white space*/
		while(array[i] == ' ' || array[i] == '\t'){
			fputc(array[i], fout);
			i++;
		}
		/*collecting the word itself(non white chars)*/
		for(j = i, k = 0; array[j] != '\n' && array[j] != '\0' && array[j] != ' ' && array[j] != '\t';j++){
			word_check[k] = array[j];
			k++;
		}
		word_check[k] = '\0';
		/*going through the existing macro links*/
		while(start_link){
			/*if there is a macro that fit this name*/
			if((strcmp(start_link->name, word_check)) == 0){
				/*we have found a macro that fit that name*/
				fputs(start_link->macro_content, fout);
				i += strlen(start_link->name);
				if(array[i] == '\n' || array[i] == '\0')
					return;
				else{
					/*if the macro is not the end of the line, than there might be more chars after it, moving the writing index 1 backward, cause all macro ending with '\n'*/
					fseek(fout, -1, SEEK_CUR);
					break;
				}
			}
			/*moving to the next link*/
			start_link = start_link->next;
		}
		/*if the link is NULL, than we didn't found any name that fit the word in the line*/
		if(!start_link){
			/*printing the word that is not a name of macro*/
			fputs(word_check , fout);
			i = j;
		}
		/*starting from the beggining of the names for every word in the line*/		
		start_link = head_link;
	}
	fputs(array + i, fout);
	return;
}

			
/*building macro structs and add them to the linked list, head_macro is the head of this list.
get:
head_macro -pointer to pointer of the head of the linked list of macro structs.
return 0 if created  new link and add it to the end of the list, else return BAD_VALUE*/
int add_macro_struct(Macro_struct **next_macro){
	/*creating new Macro_structs for new macro definition*/
	if(*next_macro == NULL){
		*next_macro = (Macro_struct *)malloc(sizeof(Macro_struct));
		/*if it didn't get the space for new struct return bad value*/
		if(*next_macro == NULL){
			fprintf(stderr,"Cannot get space for macro struct");
			return BAD_VALUE;
		}
	}
	/*if there was any macro defined before*/
	else{
		/*getting space for struct*/
		(*next_macro)->next = (Macro_struct *)malloc(sizeof(Macro_struct));
		/*if it didn't get the space for new struct return bad value*/
		if((*next_macro)->next == NULL){
			fprintf(stderr, "Cannot get space for macro struct");
			return BAD_VALUE;
		}
		*next_macro = (*next_macro)->next;
	}
	(*next_macro)->next = NULL;
	/*getting space for the name of the macro*/
	(*next_macro)->name = (char *)calloc(sizeof(char), NAME_MACRO_SIZE);
	if((*next_macro)->name == NULL){
		fprintf(stderr, "Can't get space for name of the macro");
		free(*next_macro);
		return BAD_VALUE;
	}
	/*getting space for the contnet of the new macro*/
	(*next_macro)->macro_content = (char *)calloc(sizeof(char), START_SIZE_MACRO_CONTENT);
	if((*next_macro)->macro_content == NULL){
		fprintf(stderr, "Can't get space for content of the macro");
		free((*next_macro)->name);
		free(*next_macro);
		return BAD_VALUE;
	}
	return 0;
}


/*freeing the linked list of macros.
get:
head_macro- point to the head of the linked list.
return nothing(void).*/
void free_list_macro(Macro_struct **head_macro){
	Macro_struct *next_macro = *head_macro;
	while(next_macro){
		*head_macro = next_macro;
		next_macro = next_macro->next;
		free((*head_macro)->name);
		free((*head_macro)->macro_content);
		free(*head_macro);
	}
	return;
}


/*write the content of file_name_read into file_name_write, and on the way spreading the macros in the file, deleting comments and empty lines(only spaces or\and tabs or\and newlines).
if there is no macros in the file, the writen file is the same but without comments and empty lines.
if the file is empty, return EMPTY_FILE, and doesn't create output files.
get:
file_name_read - the name of the file to read from.
file_name_write -the name of the file to write into.
return 0 if the proccess of the function succeed, else BAD_VALUE*/
int spread_macro_func(char *file_name_read, char *file_name_write){
	/*i- for loops, return_val - returning values from this function*/
	/*line_num- to print at which line an error has been found*/
	int i, line_num = 0, return_val = 0;
	/*to check if the ifle is empty*/
	long size_file;
	/*content - the line to check*/ 
	char content[LINE_LEN_MACRO];
	/*the files, fin to read from, fout to write to*/
	FILE *fin, *fout;
	/*head_macro - to hold the first struct of the macros content, next_macro - to control, create and send to functions*/
	Macro_struct *head_macro = NULL, *next_macro = NULL;
			
	/*opening (and closing if an error occured) the files*/
	/*the file to read from*/
	fin = fopen(file_name_read, "r");
	if(fin == NULL){
		fprintf(stderr ,"File to read from didn't work\n");
		return BAD_VALUE;
	}

	/*checking if a file is empty*/
	fseek(fin, 0, SEEK_END);
	size_file = ftell(fin);
	if(size_file == 0){
		/*the file is empty*/
		fclose(fin);
		return EMPTY_FILE;
	}
	/*returning to the start of the file*/
	rewind(fin);
	
	/*the file to write to*/
	fout = fopen(file_name_write, "w");
	if(fout == NULL){
		fprintf(stderr ,"File to write into didn't work\n");
		fclose(fin);
		return BAD_VALUE;
	}
	
	/*copying the content of fin to fout*/
	while(fgets(content, LINE_LEN_MACRO, fin)){
		line_num += 1;
		/*to save the last char, in case fgets had put '\0' over it*/
		if((strlen(content) == LINE_LEN_MACRO -1) && (content[strlen(content)-1] != '\n')){
			content[strlen(content)-1] = '\0';
			fseek(fin, -1, SEEK_CUR);
		}

		
		/*skiping over comments*/
		if(content[0] == ';'){
			continue;
		}
				
		/*checking for characters in the line*/ 
		for(i = 0; content[i] != '\n' &&  content[i] != '\0'; i++){
			if(content[i] == ' ' || content[i] == '\t')
				continue;
			else{
				break;
			}
		}	
		/*empty line*/
		if(content[i] == '\n')
			continue;
		/*trying to read if it is definition of macro in this line*/
		if(is_macro_def(content) != BAD_VALUE){
			/*creating new links and adding them to the list*/
			if(add_macro_struct(&next_macro) == BAD_VALUE){
				fprintf(stderr, " , line: %d\n", line_num);
				return_val = BAD_VALUE;
				break;
			}
			if(head_macro == NULL){
				head_macro = next_macro;
			}
			/*after we made sure that next_macro hold address of new struct, buiilding the macro in function*/
			if(build_macro(content, next_macro, fin, &line_num, head_macro)!= BAD_VALUE){
				/*created the struct to the macro, words, and saved them, continue to the next line after "endmcro"*/
				continue;
			}
			else{
				return_val = BAD_VALUE;
				/*changing the name of the macro cause it was illegal*/
				next_macro->name[0] = ' ';
				continue;
			}
			
		}
		/*checking if there is macro names in the line, print the line and macro if found any*/
		if(return_val != BAD_VALUE)
			is_macro_name(content, head_macro, fout);
	}

	/*closing the files*/
	fclose(fin);
	fclose(fout);
	if(return_val == BAD_VALUE){
		if(remove(file_name_write) != 0)
			fprintf(stderr, "Can't remove invalid file: %s\n", file_name_write);
	}
	/*freeing the linked list of structs*/
	free_list_macro(&head_macro);
					
	return return_val;
}

