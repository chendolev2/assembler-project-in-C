/*this file was made by Itay Markovitz and Chen Dolev*/
#include "trie.h"
#include "libraries_c.h"

/* create new trienode, returns the new trienode */
/*every label in the trie is saved with its name, value in memory and type(external/internal).
The '.entry' labels are saved in another struct*/
Trienode* create_node(char character)  { 
	Trienode *new_node = (Trienode*)malloc(sizeof(Trienode));
	if(new_node == NULL){
		fprintf(stderr, "Cannot get space for node of table_symbols\n");
		return NULL;
	} 

	/* updates new_node's data */
	new_node -> character = character;
	new_node -> end_of_word = 0;
	new_node -> binary_address = -1;
	new_node -> internal = 0;

	/*each one of the notes has CHARS options, which represent all the letters the label can continue with*/
	new_node -> children = (Trienode**)calloc(CHARS, sizeof(Trienode*));
	if(new_node -> children == NULL){
		fprintf(stderr, "Cannot get space for node of table_symbols\n");
		free(new_node);
		return NULL;
	} 

	return new_node;
}
	

/* insert a new label into the trie */
void insert_label(Trienode **root, char *label, int binary_address, int internal){  
	Trienode* current = *root;
	int i, index, length = strlen(label);
	
	for (i = 0; i < length; i++)  {
		if (label[i] >= 'a' && label[i] <= 'z') { /* lowercase */
            		index = label[i] - 'a';  
                  } else if (label[i] >= 'A' && label[i] <= 'Z') { /*uppercase*/
            	         index = label[i] - 'A' + ENGLISH_UPPER; 
                 } else {   /* digit */
            		index = label[i] - '0' + ENGLISH_UPPER_LOWER;
        	        }
        		
        	
        	       if (current -> children[index] == NULL) {
        	       		current -> children[index] = create_node(label[i]);
        	       } 
        	       current = current -> children[index];
       }
       /* marks the last node, in search it will found as legal label */
       current -> end_of_word = 1; 
       current -> binary_address = binary_address;
       current -> internal = internal;
}


/* check if the current label was already inserted into trie 
     this function goes through all letters in label and compare 
     it to exsiting path in trie, if it finds a matching path, returns FOUND */
int is_label_saved(Trienode *root, char *label, int *binary_address, int *internal, int IC_to_add){
	Trienode *current = root;
	int i, index, length = strlen(label);
	
	for (i = 0; i < length; i++)  {
		if (label[i] >= 'a' && label[i] <= 'z') { /* lowercase */
            		index = label[i] - 'a';  
        } else if (label[i] >= 'A' && label[i] <= 'Z') { /*uppercase*/
        	index = label[i] - 'A' + ENGLISH_UPPER; 
        } else {   /* digit */
            index = label[i] - '0' + ENGLISH_UPPER_LOWER;
        }
        
        /* at least one letter is missing from the potential pathway */
        if (current -> children[index] == NULL)  { 
        	return NOT_FOUND;
        }
        	        
        /* last letter is marked as legal label in the matching path */ 
        if (i == length - 1 && current->children[index]->end_of_word) {
		current -> children[index] -> binary_address += IC_to_add;
        	*binary_address = current -> children[index] -> binary_address;	 	
        	*internal = current -> children[index] -> internal; 
        	
        	return FOUND;  /* label exsits */
        }
        	        
        	        /* continue to the next letter in label */ 
        current = current -> children[index];
        }
        
    return NOT_FOUND; /* last letter wasn't marked as legal label */
 }     	        	
        	        	
 
/* free all the allocated memory for the label's trie */
void free_trie(Trienode *node)  {

	int i;
	if (node == NULL) {
		return;
	}
	/* goes through all potential children of the current node */
	for (i = 0; i < CHARS; i++) {
		free_trie(node -> children[i]);	
	}
	
	free(node -> children);
	free(node);	
}



