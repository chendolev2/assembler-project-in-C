/*this file was made by Itay Markovitz and Chen Dolev*/
#ifndef MAIN_H
#define MAIN_H

#include "trie.h"
#include "union_bits.h"
#include "labels_handle.h"
#include "libraries_c.h"

#define MEMORY_SIZE_MAX 1024 /*the memory of the machine*/
#define START_ADDRESS 100 /*the address dedicated to the beggining of the code*/
#define START_INDEX_IC 0 /*the first index to insert in instrucions, in machine code*/
#define START_INDEX_DC 0 /*the first index to insert in data, in machine code*/
#define NOT_VALID_FILE 0 /* at least one syntax error in current file, can't be coded to binary */
#define VALID_FILE 1 /* no syntax errors were found so far */
#define MEMORY_LEAK 1 /* there is no space in memory for encoding */
#define NO_MEMORY_LEAK 0 /* there is space in memory for encoding */


typedef struct main_file{
	/*IC- counting how many lines of instructions the file have, and the index to insert the next instruction*/
	/*DC- counting how many lines of directive data the file have, and the index to insert the next data 		information*/
	/*IC + DC <= 924(MEMORY_SIZE_MAX - START_ADDRESS)*/
	int IC;
	int DC;
	/*the head of the symbols table*/
	Trienode *symbols_root;
	/*to hold the instructions from the file, 12 bits each*/
	Word instructions[MEMORY_SIZE_MAX];
	/*to hold the directive data information, 12 bits each*/
	Word data[MEMORY_SIZE_MAX];
	/*the name of the file to read from*/
	char *file_name;
	/*head to linked list of label that were used in the code(in the instruction)*/
	Labels_in_use *head_label_in_use;
	/*all the label that were declared as: ".entry <LABEL>"*/
	Entries_declared *head_entries_declared;
	/*for the data and string labels*/
	Data_str_insert_IC *head_data_string;
	/*indication for the program if somewhere there was an error with the code(or at the program itself)*/
	unsigned int is_valid_file: 1;
	/*if there is too much code instructions and directives line*/
	unsigned int is_memory_leak: 1;
} Main_file;

int first_round(Main_file *main_file);
int second_round(Main_file *main_file);
int create_file_name(char **name_target, char *name_source, char add_start_char ,char *postfix);

#endif
