/*this file was made by Itay Markovitz and Chen Dolev*/
#include "main.h"

/*postfixes for the files*/
#define EXT_POST ".ext"
#define ENT_POST ".ent"
#define OBJ_POST ".ob"
#define CHAR_ADD_POST '.'
/*size for the labels_printed at the start*/
#define SIZE_START_LABEL_PRINTED 4
/*to insert the bits 10 or 01*/
#define INTERNAL_ARE (2)
#define EXTERNAL_ARE (1)

#define OPEN_FILE 1


/*print into file numbers as they writen in base 64.
get:
left_num- the number that will show at the left side when printed.
right_num - the number to print in the right side when printed.
fout- the file to write into.
return void.*/ 
void print_base64(unsigned int left_num, unsigned int right_num, FILE *fout){
	const char base64_char[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	fprintf(fout, "%c", base64_char[(int)left_num]);
	fprintf(fout, "%c\n", base64_char[(int)right_num]);
	return;
}


/*printing the machine code in base64, into the specified file.
get:
main_file-the stucrt with the arrays and indexes.
fout-the file to write into.
return void.*/
void print_ob_file(Main_file *main_file, FILE *fout){
	int i;
	if(main_file->IC ==  START_INDEX_IC){
		if(main_file->DC == START_INDEX_DC){
			fprintf(fout,"0 0\n");
			return;
		}
		else{
			fprintf(fout, "0 %d\n", (main_file->DC - START_INDEX_DC));
		}
	}
	else{
		fprintf(fout,"%d %d\n", (main_file->IC - START_INDEX_IC), (main_file->DC - START_INDEX_DC));
	}
	
	/*printing all the machine code in base64, first instructions then data*/
	for(i = START_INDEX_IC; i < main_file->IC; i++){
		print_base64(main_file->instructions[i].six_six.left_six, main_file->instructions[i].six_six.right_six, fout);
	}

	for(i = START_INDEX_DC; i < main_file->DC ; i++){
		print_base64(main_file->data[i].six_six.left_six, main_file->data[i].six_six.right_six, fout);
	}
	return;
}

/*create file with the postfix, as needed, treat the opening of it.
get:
old_name- the old name of the file.
file_ptr- pointer to pointer of file, to open it.
postfix- the requsted postfix.
return int- BAD_VALUE if there was error in the function, else 0*/
int open_file_postfix(char *old_name, FILE **file_ptr, char *postfix){
	char *temp_name;
	if(create_file_name(&temp_name, old_name, CHAR_ADD_POST, postfix) == BAD_VALUE)
		return BAD_VALUE;
	/*opening the file to write into*/
	*file_ptr = fopen(temp_name, "w");
	if(*file_ptr == NULL){
		fprintf(stderr, "Can't open the file: %s\n", temp_name);
		free(temp_name);
		return BAD_VALUE;
	}	
	/*all went well*/
	free(temp_name);
	return 0;
}

	
/*inserting the label address into the the IC index.
get:
main_file- pointer to the main_file struct, hold the array "instructions".
label_address- the address to insert.
internal-for ARE ,not internal(0):insert 01, yes internal(1):insert 10.
ic_index-the index to insert into in instructions array.
return void.*/
void insert_label_address(Main_file *main_file, int label_address, int internal, int ic_index){
	main_file->instructions[ic_index].addr_bit.addr = label_address;
	if(internal == INTERNAL_LABEL)
		main_file->instructions[ic_index].addr_bit.ARE = INTERNAL_ARE;
	else
		main_file->instructions[ic_index].addr_bit.ARE = EXTERNAL_ARE;
	return;
}

/*making name of file with requested postfix, then deleting it from the system(remove).
get:
name-the name of the file.
postfix- the postfix to change to.
reutrn void.*/
void delete_file_name_postfix(char *file_name, char *postfix){
	char *name_del;
	if(create_file_name(&name_del, file_name, CHAR_ADD_POST, postfix) == BAD_VALUE){
		fprintf(stderr, "Can't delete file: %s\n", name_del);
		return;
	}
	if(remove(name_del) != 0){
		fprintf(stderr, "Can't delete file: %s\n", name_del);
	}
	free(name_del);
	return;
}

/*create file names with postfix requsted.
get:
name_target- the new name with the requsted postfix.
name_source- the original name.
add_start_char- the char(the last one found), to add the postfix starting in its index.
postfix- the postfix to add.
return BAD_VALUE if an error occured in the function, else 0*/
int create_file_name(char **name_target, char *name_source, char add_start_char ,char *postfix){
	int len_name = strrchr(name_source,add_start_char)-name_source;
	/*getting place for the new name*/
	*name_target = (char*)calloc(sizeof(char), len_name + strlen(postfix) + 1);
	if(!(*name_target)){
		fprintf(stderr,"Can't make the file name: %s, with the postfix: %s\n", name_source, postfix);
		return BAD_VALUE;
	}
	/*creating the new name in the placed that received*/
	strncpy(*name_target, name_source, len_name);
	strcat(*name_target, postfix);
	return 0;
}

/*printing the label name and address into the received file.
get:
label_name-the name to print.
address-the address of the label.
file_ptr-the file to write into.
return void.*/
void print_label_file(char *label_name, int address, FILE *file_ptr){
	fprintf(file_ptr, "%s\t%u\n", label_name, address);
	return;
}


/*checking if all the .entry labels, was assigned somewhere in the file, then wirting them into a ".ent" file.
get:
main_file- hold the root of the tire with the labels, and if the file is valid.
return BAD_VALUE on error in the function, else 0.*/
int checking_entries_declared(Main_file *main_file){
	
	/*binary_address- the place to insert the machine code into*/
	int opened_ent_file = !OPEN_FILE ,binary_address, internal, return_value = 0;
	FILE *file_ent;
	Entries_declared *temp = main_file->head_entries_declared;
	/*no label were declared as ".entry"*/
	if(temp == NULL)
		return 0;
	
	/*opening the file needed*/
	if(main_file->is_valid_file == VALID_FILE){
		if(open_file_postfix(main_file->file_name, &file_ent, ENT_POST) == BAD_VALUE){
			main_file->is_valid_file = NOT_VALID_FILE;
			return_value = BAD_VALUE;
		}
		else{
			opened_ent_file = OPEN_FILE;
		}
	}
	/*going through all the labels in the list*/
	while(temp){
		/*checking if the label was assigned*/
		if(is_label_saved(main_file->symbols_root,temp->name_declared,&binary_address,&internal,0) == FOUND){
			/*the case where label was declared as entry and extern*/
			if(internal == EXTERNAL_LABEL){
				fprintf(stderr, "Label:%s was declared \".entry\" and \".extern\", line: %d\n", temp->name_declared, temp->line_number);
				main_file->is_valid_file = NOT_VALID_FILE;
			}
			/*if the file is valid*/ 
			if(main_file->is_valid_file == VALID_FILE)
				print_label_file(temp->name_declared, binary_address, file_ent);
		}
		/*the label was not in the trie*/
		else{
			fprintf(stderr,"Found \".entry\" label with no value assigned too, label: %s, line: %d\n", temp->name_declared, temp->line_number);
			main_file->is_valid_file = NOT_VALID_FILE;
		}
		temp = temp->next_entry;
	}
	/*closing the file*/
	if(opened_ent_file == OPEN_FILE){
		fclose(file_ent);
		/*if through the function, an error in the labels was found, delete the file*/
		if(main_file->is_valid_file == NOT_VALID_FILE){
			delete_file_name_postfix(main_file->file_name, ENT_POST);	
		}
	}
	return return_value;
}


/*checking the use of the labels and inserting their address to instructions in main_file, printing the extern labels
data into file with postfix ".ext".
get:
main_file- to get from the labels used, instructions, the symbols table root ect'.
return BAD_VALUE if error occurred in the function, else 0.*/
int handle_address_labels_used(Main_file *main_file){
	/*binary_address the address of the label assignment of value*/
	/*interanl if the label is enternal or external*/
	int binary_address, internal, return_value = 0;
	int ext_file_opened = !OPEN_FILE;
	FILE *file_ext;
	Labels_in_use *temp = main_file->head_label_in_use;
	
	/*going through all the list*/
	while(temp){
		/*checking if the labels were inserted to the symbols table*/
		if(is_label_saved(main_file->symbols_root, temp->name, &binary_address, &internal,0) == FOUND){
			if(main_file->is_valid_file == VALID_FILE){
				/*if the label is external- need to print its data in .ext*/
				if(internal == EXTERNAL_LABEL){
					/*etxern label addresses are unknown, so to overide prev given address insert address 0*/
					binary_address = 0;
					if(ext_file_opened == !OPEN_FILE){
						/*trying to open the.ext file*/
						if(open_file_postfix(main_file->file_name, &file_ext, EXT_POST) == BAD_VALUE){
							main_file->is_valid_file = NOT_VALID_FILE;
							return_value = BAD_VALUE;
							temp=temp->next;
							continue;
						}
						ext_file_opened = OPEN_FILE;
					}
					/*if they are externs, print them in their file*/
					print_label_file(temp->name, temp->binary_address, file_ext);
				}
				/*putting the correct address int instructions*/
				insert_label_address(main_file, binary_address, internal, temp->binary_address - START_ADDRESS);	
			}			
		}
		/*didn't found the label in the symbols table*/
		else{
			fprintf(stderr, "Label: %s ,was used but didn't got a proper assignment of value, line: %d\n", temp->name, temp->line_number);
			main_file->is_valid_file = NOT_VALID_FILE;
		}
		temp=temp->next;
	}

	/*closing and deleting the file if needed*/
	if(ext_file_opened){
		if(fclose(file_ext) == EOF){
			fprintf(stderr, "Can't close file: %s, with postfix: %s\n", main_file->file_name, EXT_POST);
		}
		if(main_file->is_valid_file == NOT_VALID_FILE){
			delete_file_name_postfix(main_file->file_name, EXT_POST);
		}
	}
	return return_value;
}


/*checking if the labels were used correct, inserting their address, printing thier inforamtion
into file dedicated to that. Then print the machine code that was build into its file, in base64.
get:
main_file-contain the information needed about the labels.
return BAD_VALUE if somthing went wrong in the function(or in one of the sub functions).*/
int second_round(Main_file *main_file){
	/*file to print into, machine code in base64*/
	FILE *ob_file = NULL;
	/*first checking if all the .entry labels were valid*/
	
	checking_entries_declared(main_file);
	/*checking and insert the addresss of the labels that were used, also print label info into .ext file(if needed)*/
	
	handle_address_labels_used(main_file);
	
	/*if we reached here than the labels are OK and now opening .ob file to write into*/
	if(main_file->is_valid_file == VALID_FILE){
		if(open_file_postfix(main_file->file_name, &ob_file, OBJ_POST) != BAD_VALUE){
			/*printing the machine code in base64*/
			print_ob_file(main_file, ob_file);
			fclose(ob_file);
		}
	}
	
	return 0;
}



