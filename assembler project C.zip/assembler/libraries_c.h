/*this file was made by Itay Markovitz and Chen Dolev*/
#ifndef LIB_C_H
#define LIB_C_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BAD_VALUE -2 /*default for value dedicated to "bad" results*/

#endif
