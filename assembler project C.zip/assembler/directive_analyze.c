/*this file was made by Itay Markovitz and Chen Dolev*/
#include "syntax.h" 
/*This program analyses directive sentences, updates file_status and data accordingly (file_struct), and codes each defined value (data/string) 
	in case of no memory leak. The directive types are: data, string, entry, extern */

/* checks whether the (directive) type is valid */
#define DIRECTIVE_TYPE_VALID(type) \
     strcmp(type, ".string") == 0 || \
     strcmp(type, ".data") == 0 || \
     strcmp(type, ".extern") == 0 || \
     strcmp(type, ".entry") == 0


/* check validation of entry type parameter and insert it to head_entries_declared (linked list) - 
	later (in the second round), for each valid parameter (variable) will be checked if there is a definition in the current file.
	In case of no definition - error (entry label should be defined in the current file.
	PARAMETERS: line = directive definition, file_struct = file's data and status, line_num = number of row in am file
	return GOOD_PARAM if parameter is valid and inserted to the linked list, BAD_PARAM otherwise */
int operate_entry_type(char* line, Main_file* file_struct, char** invalid_name_label, int line_num) {	
	char entry_value[MAX_LINE_LENGTH] = {0}; /* to save the entry's parameter */
	int i = 0;
	int len_entry_value;

    for(i = 0; *line != ' ' && *line != '\0' && *line != '\n';) {
    	if (*line == ',') {
		fprintf(stderr, "Illegal comma in 'entry' definition, line: %d\n", line_num);
    		file_struct -> is_valid_file = NOT_VALID_FILE;
    		return BAD_PARAM;
    	}
	entry_value[i++] = *line++;  /* copies current operation to 'operation name */
	}
	entry_value[i] = '\0';
	len_entry_value = strlen(entry_value); 
	
	if (check_extra_characters(line, file_struct, line_num) == NOT_VALID_FILE) { /* extra character beyond the entry value is an error */
		return BAD_PARAM;
	}

	/*check validation for entry_value as label */	
	if (is_valid_label_exists(entry_value, file_struct, len_entry_value, invalid_name_label, line_num) == LABEL_DEF_ILLEGAL) {
	return BAD_PARAM;
	}
	if (create_link_entry(&file_struct -> head_entries_declared, entry_value, line_num) == BAD_VALUE) {
       		file_struct -> is_valid_file = NOT_VALID_FILE;
        		return BAD_PARAM;
    }

	return GOOD_PARAM;
}

/* check validation of string type parameter - opening and closing quotation marks, printable characters. In case of 
	no memory leak, code each character int the string, including null character at the end
	PARAMETERS: line = directive definition, file_struct = file's data and status, line_num = number of row in am file
	return GOOD_PARAM if parameter is valid, BAD_PARAM otherwise */
int operate_string_type(char* line, Main_file* file_struct, int line_num) {	
	int length = strlen(line);
	int IC = file_struct-> IC; /* counter for instruction lines */
	
	/* check if opening or closing quotation marks is missing */
	if (line[0] != '\"') {  /* opening quotation is missing */
		fprintf(stderr, "In '.string' definition, the string '%s' doesn't start with opening "\
		"quotation marks, line: %d\n", line, line_num);
		file_struct -> is_valid_file = NOT_VALID_FILE;
    	return BAD_PARAM; 
  }
    	
    if (!((line[length-1] == '\n' && line[length-2] == '\"') || (line[length -1] == '\"'))) { 
    	/* closing quotation is missing */
    	fprintf(stderr, "In '.string' definition, the string '%s' doesn't end with closing "\
		"quotation marks, line: %d\n", line, line_num);
		file_struct -> is_valid_file = NOT_VALID_FILE;
    	return BAD_PARAM; 
  }

	line++; /* skips opening quotation marks */
	while (*line != '\"')  { /* it's not the end of the string */
		if (!(*line >= SPACE_ASCII && *line <= TILDE_ASCII)) {
			fprintf(stderr, "In '.string' definition, one of the characters in the string isn't a "\
			"printable ASCII character, line: %d\n", line_num);
			file_struct -> is_valid_file = NOT_VALID_FILE;
			return BAD_PARAM;
		}
		if (file_struct -> is_memory_leak == NO_MEMORY_LEAK && is_memory_leak(IC, file_struct->DC, file_struct, line_num) == NO_MEMORY_LEAK) {  /* enough memory space for encoding */
			file_struct->data[file_struct->DC].val_bit.value = *line; /* updates the binary code for the current character */
			file_struct->DC  = file_struct ->DC + 1; /* promotes the counter to the next available position */
		}
		line++;
	} /* end of loop */
	
	if (file_struct -> is_memory_leak == NO_MEMORY_LEAK && is_memory_leak(IC, file_struct->DC, file_struct, line_num) == NO_MEMORY_LEAK) {  /* enough memory space for encoding */
		file_struct->data[file_struct ->DC].val_bit.value = 0; 	/* updates binary code for the null char */
		file_struct->DC  = file_struct ->DC + 1; /* promotes the counter to the next available position */
	}
	line++; /* skips closing quotation marks */

	/* check for extra characters, extra characters is an error */
	if (check_extra_characters(line, file_struct, line_num) == VALID_FILE) {
			return GOOD_PARAM; 		
	}
	return BAD_PARAM;
}

/* check validation of each extern/entry type parameter (there might be more than one parameter 
	but this function checks only the current parameter). At first it copies the parameter's value base on its end position in line.
	for data - checks that parameter is a valid number and codes its value (in case of no memory leak)
	for data - checks that parameter is a valid label and inserts it to the symbols label
	PARAMETERS: end_param_position = position in memory the parameter's representation ends, line = directive definition, 
	file_struct = file's data and status, type = .data/.extern, Invalid_name_label = list for saved words forbidden for labels,
	line_num = number of row in am file 
	return GOOD_PARAM if parameter is valid, BAD_PARAM otherwise */
int evaluate_data_extern_parameter(char* end_param_position, char* line, Main_file* file_struct,\
												 char* type, char** invalid_name_label, int line_num) {
	int parameter_length = end_param_position - line; /* Calculate parameter's length */
	char parameter_buffer[MAX_LINE_LENGTH] = {0}; /* to save the current parameter */
	int current_parameter_value; /* value of the converted parameter from string to number */
	int label_DC = file_struct-> DC;
	int label_param_status; /* is label parameter's definition legal */
	
	strncpy(parameter_buffer, line, parameter_length);  /* copy parameter to parameter_buffer */
	parameter_buffer[parameter_length] = '\0';
	erase_extra_spaces(parameter_buffer);

	if (strcmp(type, ".data") == 0) {
		/* check current parameter validation (number between MIN_NUM_12 to MAX_NUM_12) */
		if (num_param_validation(parameter_buffer, &current_parameter_value, file_struct, line_num,\
													MIN_NUM_12, MAX_NUM_12) == ILLEGAL_PARAM)  {
			return BAD_PARAM;
		}
		/* parameter is legal */
		/* updates the binary code for the current parameter */
		if (file_struct -> is_memory_leak == NO_MEMORY_LEAK && is_memory_leak(file_struct-> IC, file_struct->DC, file_struct, line_num) == NO_MEMORY_LEAK) {  /* enough memory space for encoding */
			file_struct->data[file_struct->DC].val_bit.value = current_parameter_value; 
			file_struct-> DC  = file_struct -> DC + 1; /* promotes the counter to the next available position */
		}
	} else {  /* type is ".extern" */

		label_param_status = is_valid_label_exists(parameter_buffer, file_struct, parameter_length, invalid_name_label, line_num);
		if (label_param_status == LABEL_DEF_ILLEGAL) {
			return BAD_PARAM;
		}
		if (label_param_status == LABEL_EXISTS) {	
			if (insert_label_if_new(line, parameter_buffer, file_struct, line_num, EXTERNAL_LABEL, file_struct-> IC, label_DC, DIRECTIVE) == INSERTION_LABEL_FAILURE) {
			return BAD_PARAM;
			}	
		}
    }
    return GOOD_PARAM;
}		

/* check validation for .data/.extern parameters and missing/illegal commas between parameters.
	 Evaluates each one of the parameters separately.
	 PARAMETERS: line = directive definition, file_struct = file's data and status, directive_type = .data/.extern,
	 			 invalid_name_label = list for saved words forbidden for labels,line_num = number of row in am file 
	return GOOD_PARAM if parameter or parameters valid, BAD_PARAM otherwise */
int operate_data_extern_type(char* line, Main_file* file_struct, char* directive_type, char** invalid_name_label, int line_num) {
	char* comma_position;/* first occurrence of comma in current line */
	char* last_param_end; /* character that represents the end of the last parameter */
	int length = strlen(line); 
	int parameter_count = 0;
	int comma_status = NO_MISSING_COMMA;
	int return_val = GOOD_PARAM;
	
	if ((line[length-1] == '\n' && line[length-2] == ',') || (line[length -1] == ',')) { 
    	/* definition ends with invalid comma */
    	fprintf(stderr, "Invalid comma at the end of '%s' definition, line: %d\n", directive_type, line_num);
		file_struct -> is_valid_file = NOT_VALID_FILE;
    	return BAD_PARAM; 
	}
	
	/* check if there is a missing comma between parameters */
	 is_missing_comma_parameters(line, &parameter_count, &comma_status, line_num);
	 if (comma_status == MISSING_COMMA) {
	 	fprintf(stderr, "At least one comma is missing between the parameters of "\
			"directive type '%s' definition, line: %d\n", directive_type, line_num);
		file_struct -> is_valid_file = NOT_VALID_FILE;
	 	return BAD_PARAM;
	}
	/* read all parameters separated by commas */
	while (*line != '\n' && *line != '\0')  { /* not the end of the row */ 
		comma_position = strchr(line, ',');

		if (comma_position != NULL) {
			if (evaluate_data_extern_parameter(comma_position, line, file_struct, directive_type, invalid_name_label, line_num) == BAD_PARAM) {
				return_val = BAD_PARAM;
        	}
        
        	line = comma_position + 1; /* promotes line after the current parameter and comma */
        	for (; isspace(*line); line++);  /* skip space */
        	} else {
        		break;
       		}
	}
	 
     for (; isspace(*line); line++);  /* skip space */
	 last_param_end = line;
	 while (*last_param_end != ' ' && *last_param_end != '\n' && *last_param_end != '\0')  {
	 	last_param_end ++;
	 }
	 
	 if (*last_param_end == ' ') {
	 	fprintf(stderr, "At least one comma is missing between the parameters of '%s' "\
	 		"definition, line: %d\n", directive_type, line_num);
	 	file_struct -> is_valid_file = NOT_VALID_FILE;
	 	return BAD_PARAM;
	 	
	 } else {  
	 	if (evaluate_data_extern_parameter(last_param_end, line, file_struct, directive_type, invalid_name_label, line_num) == BAD_PARAM) {
	 		return_val = BAD_PARAM;
	 	}
	 }

	 return return_val;		 
}


/* get directive definition, analyze its directive type and its parameters (each directive type is analyzed differently.
	In case of label definition, insert it to the symbols table if the directive type is string/data, otherwise, print warning
	and ignore the label. Search for invalid commas and that there is at least one parameter for each valid directive type
	PARAMETERS: line = directive definition, label = label's definition of current line, file_struct = file's data and status, 
	 			 invalid_name_label = list for saved words forbidden for labels, line_num = number of row in am file 
	return VALID_FILE if the definition is valid, NOT_VALID_FILE otherwise */

int is_directive_valid(char* line, char* label, Main_file* file_struct, char** invalid_name_label, int line_num) {
	int label_def_exists = NO_LABEL;
	int length = strlen(line); 
    char directive_type[MAX_LINE_LENGTH] = {0};
	int j;
	int label_DC = file_struct -> DC; /* current DC value for saving the line's label (DC = counter for directive lines) */

	if (line[0] == ',' || (line[length-1] == '\n' && line[length-2] == ',') || (line[length -1] == ',')) {  /* definition ends with invalid comma */
	fprintf(stderr, "Invalid comma at the %s of the line, line: %d\n", line[0] == ','? "begining":"end", line_num);
	file_struct -> is_valid_file = NOT_VALID_FILE;
	return NOT_VALID_FILE; 
	}
	
	label_def_exists = is_label_def_exists(line, label, file_struct, invalid_name_label, line_num); 
	if (label_def_exists == LABEL_EXISTS) {
    	for (; *line != ':'; line++);  line++; 
		for (; isspace(*line); line++);  
	}
	
    if (label_def_exists == LABEL_DEF_ILLEGAL)  {
    		return NOT_VALID_FILE; 
    }
    
	if (*line == ',') {
		fprintf(stderr, "Illegal comma before the directive type, line: %d\n", line_num);
        file_struct -> is_valid_file = NOT_VALID_FILE;
        return NOT_VALID_FILE;
    }

	/* check for directive type */
	for(j = 0; *line != ' ' && *line != '\0' && *line != '\n' && *line != ',';) {
		directive_type[j++] = *line++;  /* copies current operation to 'operation name */
    }
    directive_type[j] = '\0';
    
    if (!(DIRECTIVE_TYPE_VALID(directive_type))) {
    	fprintf(stderr, "Directive type: '%s' is illegal, line: %d\n", directive_type, line_num);
        file_struct -> is_valid_file = NOT_VALID_FILE;
        return NOT_VALID_FILE;
    }
    
    erase_extra_spaces(line);
    if (*line == ',') {  /* Illegal comma after directive type */
		fprintf(stderr, "Illegal comma between the directive type '%s' and its parameters, line: %d\n",directive_type, line_num);
    	file_struct -> is_valid_file = NOT_VALID_FILE;
    	return NOT_VALID_FILE;
    }
    
    /* warning if .data/.string type defined without a label and can't be used in the program */
    if ((strcmp(directive_type, ".data") == 0 || strcmp(directive_type, ".string") == 0) && label_def_exists == NO_LABEL) {
    	 printf("Warning: defining '%s' type without a label means it can't be used in the program,"\
    	  " line: %d\n", directive_type, line_num); 
    }
    /* warning if there is a label definition at the beginning of .entry/.extern line */	  
    if ((strcmp(directive_type, ".entry") == 0 || strcmp(directive_type, ".extern") == 0) && label_def_exists == LABEL_EXISTS) {
    	printf("Warning: label '%s' that is defined before '%s' type can't be used in the program,"\
    	" line: %d\n", label, directive_type, line_num); 
    }
    
    	
	if (*line == '\0' || *line == '\n') { /* no parameters after directive definition - error */
		fprintf(stderr, "Type '%s' requires %s one parameter, line: %d\n", directive_type,\
		(strcmp(directive_type, ".string") == 0 || strcmp(directive_type, ".entry") ==0)? "exactly": "at least", line_num);
    	file_struct -> is_valid_file = NOT_VALID_FILE;
    	return NOT_VALID_FILE;
	}

    if (strcmp(directive_type, ".string") == 0) {
        if (operate_string_type(line, file_struct ,line_num) == BAD_PARAM) {
       		return NOT_VALID_FILE;
       	}
       	/* insert label to symbols table if it exists, is valid and wasn't defined twice */
        if (label_def_exists == LABEL_EXISTS) {
        	if (insert_label_if_new(line, label, file_struct, line_num, INTERNAL_LABEL, file_struct->IC, label_DC, DIRECTIVE) == INSERTION_LABEL_FAILURE) {
        		return NOT_VALID_FILE;
        	}
		if(add_new_link_data_string(&file_struct->head_data_string, label) == BAD_VALUE){
			return NOT_VALID_FILE;
		}
        }
        return VALID_FILE;
	
    } else if (strcmp(directive_type, ".data") == 0) {
        if (operate_data_extern_type(line, file_struct, directive_type, invalid_name_label, line_num) == BAD_PARAM) {
        	return NOT_VALID_FILE;
        }
        /* insert label to symbols table if it exists, is valid and wasn't defined twice */	
        if (label_def_exists == LABEL_EXISTS) {
        	if (insert_label_if_new(line, label, file_struct, line_num, INTERNAL_LABEL, file_struct->IC, label_DC, DIRECTIVE) == INSERTION_LABEL_FAILURE) {
        		return NOT_VALID_FILE;
        	}
		if(add_new_link_data_string(&file_struct->head_data_string, label) == BAD_VALUE){
			return NOT_VALID_FILE;
		}
        }
        return VALID_FILE;
         
    } else if (strcmp(directive_type, ".extern") == 0) {
    	if (operate_data_extern_type(line, file_struct, directive_type, invalid_name_label, line_num) == BAD_PARAM) {
        	return NOT_VALID_FILE;
    	}
    
    } else  { /* directive_type = entry */
    	if (operate_entry_type(line, file_struct, invalid_name_label, line_num) == BAD_PARAM) {	
    		return NOT_VALID_FILE;
    	}  
    } 
     return VALID_FILE;    	
}

