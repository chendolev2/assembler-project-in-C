/*this file was made by Itay Markovitz and Chen Dolev*/
#include "syntax.h"

/* check if there are missing commas between parameters in instruction/directive line (at least one comma is missing).
	Count number of parameters, depends on the number of commas. 
	PARAMETERS: line = directive/instruction, parameter_counter = counts the number of parameters
	 depends on the number of commas, comma_status = MISSING_COMMA/NO_MISSING_COMMA,  
	line_num = number of row in the am file 
	return MISSING_COMMA if there is at least one missing comma, NO_MISSING_COMMA otherwise */
void is_missing_comma_parameters(char* line, int* parameter_counter, int* comma_status, int line_num) {
	char *line_helper = line;
    while (*line_helper != '\n' && *line_helper != '\0') {  /* not the end of line */
        if (*line_helper != ' ' && *line_helper != ',') {
            line_helper++;
             if (*parameter_counter == 0) {
    			(*parameter_counter)++;
    		}
        }
        
        /*check if there is space without a comma*/
        if (*line_helper == ' ') {
            if ((*(line_helper+1)) != ',')  {
                *comma_status = MISSING_COMMA;
                line_helper++;
            } else {
            	line_helper++;
            }
        }
        /*found space, add 1 to the counter*/
        if (*line_helper == ',')  {
           (*parameter_counter)++;
            line_helper ++;
            for (; isspace(*line_helper); line_helper++);
        }  
    }
    
    return;
}

/* check if there is a memory leak by checking if the sum of the instruction counter (IC) and the directive counter (DC) is less
	than MEMORY_SIZE_MAX - START_ADDRESS. This function is called before coding values to the memory.
	PARAMETERS: required IC = IC needed for coding, required_DC = DC needed for coding, 
	file_struct = file's data and status, line_num = number of row in the am file
	return MEMORY_LEAK if required_DC + required_IC is bigger than the memory allocated for coding, NO_MEMORY_LEAK otherwise */
int is_memory_leak(int required_IC, int required_DC,  Main_file* file_struct, int line_num) {
	if ((required_IC) + (required_DC) >= MEMORY_SIZE_MAX - START_ADDRESS) { 
		fprintf(stderr, "MEMORY_LEAK! The continuation of the program can't be coded, line: %d\n", line_num);
		file_struct -> is_memory_leak = MEMORY_LEAK;
		file_struct -> is_valid_file = NOT_VALID_FILE; 
		return MEMORY_LEAK;
	}
	return NO_MEMORY_LEAK;
}

/* Checks that there are no two consecutive commas. Two commas are considered consecutive even if they are separated by a space (only).
	PARAMETERS: line = directive/instruction, file_struct = file's data and status, line_num = number of row in the am file
	return CONSECUTIVE_COMMAS if two consecutive commas were found, NO_CONSECUTIVE_COMMAS otherwise */
int check_consecutive_commas(char* line, Main_file* file_struct, int line_num)
{
    while (*line != '\0' && *line != '\n') {
    	if (*line == ',') {
    	    line ++;
    	    while (isspace(*line)) {
                line++;
    	    }
    	    if(*line == ',')  { /* found consecutive commas */
    			fprintf(stderr, "Consecutive commas aren't allowed, line: %d\n", line_num);
    			file_struct -> is_valid_file = NOT_VALID_FILE;
    		    return CONSECUTIVE_COMMAS;
    	    }
    	}
	if(*line != '\0' && *line != '\n'){
       		line ++;
	}
    }		 
    return NO_CONSECUTIVE_COMMAS; 
}


/* erase extra spaces from the line or the parameter -
	* leading spaces 
	* trailing spaces 
	* converts to one space if there is more than one space in a row between words in the line
	PARAMETERS: line_or_param = instruction/directive line or parameter
	return none (changes line_or_param) */	  
void erase_extra_spaces(char* line_or_param)  {
    char* source = line_or_param; /* for checking the string */
    char* destination = line_or_param; /* for modified string */
    int space_counter = 0; /* to check if there is more than one space in a row */
    int is_non_space_char = 0; /* 0 if the current character is space */

    /* erase leading spaces */
    while (isspace(*source)) {
        source++;
    }

    /* remove extra spaces and trailing spaces */
    while (*source) {
        if (isspace(*source)) {
            space_counter++;
        } else {
            if (is_non_space_char && space_counter > 0) {
                *destination++ = ' '; /* keep only one space between words */
            }
            *destination++ = *source;
            space_counter = 0;
            is_non_space_char = 1;
        }
        source++;
    }

    /* trailing spaces at the end of the string */
    while (destination > line_or_param && isspace(*(destination - 1))) {
        destination--;
    }
    *destination = '\0';
}


/* Check if the current line is directive by searching for a dot character.
	PARAMETERS: line = directive/instruction
	return DIRECTIVE if dot character was found, INSTRUCTION otherwise */
int is_directive_definition(char* line)  { 
	char* line_helper = line;
	
	if (strchr(line_helper, ':') != NULL) {   /*skips label */
		for (; *line_helper != ':'; line_helper++);  line_helper++; 
		for (; isspace(*line_helper); line_helper++);
	}
	
	if (*line_helper == '.') {
		return DIRECTIVE;
	}			
						
	return INSTRUCTION;	  
}


/* Check if the current line has valid syntax by analyzing its type (instruction/directive).
	The line is being checked according to the type and its values are coded if the syntax is valid and there is no memory leak. 
	PARAMETERS: line = directive/instruction, file_struct = file's data and status, line_num = number of row in the am file
	return VALID_FILE if the syntax of the current line is valid, NOT_VALID_FILE otherwise */
int is_syntax_valid(char* line, Main_file* file_struct , int line_num) {
/*operations array with their information - opcode name, parameters num, source and target methods*/
	struct operation_data* operations = get_operations_array(); 
/* saved names in the computer that can't be label's name */
	char** invalid_name_label = get_invalid_name_label_array();
	char label[MAX_LABEL_LENGTH + 1] = {0}; 

	/* erases leading and trailing spaces, converts few spaces to one space */
	if (check_consecutive_commas(line, file_struct, line_num) == CONSECUTIVE_COMMAS) {
		return NOT_VALID_FILE;
	}
	erase_extra_spaces(line);

	if (is_directive_definition(line)) {
	    return is_directive_valid(line, label, file_struct, invalid_name_label, line_num);
	} else {
	    return is_instruction_valid(line, label, file_struct, operations, invalid_name_label, line_num);
	}
}		
		

	
				
/* Check if the current line has extra characters than expected - syntax error.
	PARAMETERS: line = directive/instruction, file_struct = file's data and status, line_num = number of row in the am file
	return VALID_FILE if there is no extra characters, NOT_VALID_FILE otherwise */
int check_extra_characters(char* line, Main_file* file_struct, int line_num) {
	
	if (*line != '\n' && *line != '\0')  { /* extra character after the instruction line */
		fprintf(stderr, "Extraneous text at the end of the line, line: %d\n", line_num);
		file_struct -> is_valid_file = NOT_VALID_FILE;
		return NOT_VALID_FILE; 
	}

	return VALID_FILE;
}

/* Check if the current string is integer by checking the first characters (plus/minus/digit).
	All characters afterwards should be digits. This function is used as part of number validation function
	PARAMETERS: string = the string that might be a valid number
	return 0 for invalid number, 1 for valid number */	
int is_integer(char* string) {
	int i, length = strlen(string);
	if (!(string[0] == '+' || string[0] == '-' || isdigit(string[0]))) {
		return 0;
	}
	
	for (i= 1; i < length; i++) {
		if (!isdigit(string[i])) {
			return 0;
		}
	}
	return 1;
}
	
		
/* Check if the current parameter is a valid number between min_value to max_value, save its value in param_num_value if valid. 
	PARAMETERS: param = current parameter that is being checked as a valid number, param_num_value = valid number's value,
	 file_struct = file's data and status, line_num = number of row in the am file, min_value = minimum value that is possible
	 for a valid number, max_value = maximum value that is possible for a valid number
	return ILLEGAL_PARAM for an invalid number, NUM otherwise */
int num_param_validation(char* param, int *param_num_value, Main_file* file_struct, int line_num,\
								int min_value, int max_value) {
	int num = min_value - 1; /* initializes num */

	/* check if parameter is an integer in the valid range */
	if (is_integer(param)) {
		num = atoi(param);
		if (num >= min_value && num <= max_value) {  /* in legal range */
			*param_num_value = num; 
			return NUM; /* parameter is valid number */
		} else { 
		/* update error message - number not in range */
			fprintf(stderr, "Invalid parameter - the number you entered as parameter is not in range %d to %d, line: %d\n", 
				min_value, max_value, line_num);
			file_struct -> is_valid_file = NOT_VALID_FILE;												
			return ILLEGAL_PARAM;
		}
	} else {    
	/* update error message - not a valid number */
	fprintf(stderr, "Invalid parameter, '%s' is not a valid number, line: %d\n", param, line_num);
	file_struct -> is_valid_file = NOT_VALID_FILE;
	return ILLEGAL_PARAM;
	}
}


/* Insert current label to the symbols table if it does not exist in the symbol table, if it already exists - error 
	PARAMETERS: line = instruction/directive , label = current label that is being checked, 
	 file_struct = file's data and status, line_num = number of row in the am file, label_type = internal/external,
	 IC = instruction counter for coding instructions, DC = directive counter for coding directive lines,
	 STATUS = DIRECTIVE/INSTRUCTION 
	return INSERTION_LABEL_FAILURE for failure during the insertion, INSERTION_LABEL_SUCCESS otherwise */
int insert_label_if_new(char* line, char* label, Main_file* file_struct, int line_num, int label_type, int IC, int DC, int status) {

    int binary_address; /* address of the binary code representation */
	int is_internal_label;  /* is updated in function is_label_saved */	 
	 
	 if (status  == INSTRUCTION) {
	 	binary_address = IC + START_ADDRESS;
	 } else {  /* status  == DIRECTIVE */
	 	binary_address = DC + START_ADDRESS;
	 }
    /* inserts label into the symbols table */
    if (is_label_saved(file_struct -> symbols_root, label, &binary_address, &is_internal_label, 0)) {
    	fprintf(stderr, "Label %s was already defined as %s label, line: %d\n", label,\
    		 is_internal_label? "internal": "external", line_num);
		file_struct -> is_valid_file = NOT_VALID_FILE;
		return INSERTION_LABEL_FAILURE;
	}	
	insert_label(&(file_struct -> symbols_root), label, binary_address, label_type);
	return INSERTION_LABEL_SUCCESS;
}   


/* Check if the current label is valid and all its necessary features are exists - starts with letter, no more than MAX_LABEL_LENGTH
	characters, characters are only digits or letters, and the name is not a saved word of instruction/directive type
	PARAMETERS: label = current label that is being checked, file_struct = file's data and status,
	label_length, invalid_name_label = list for saved words forbidden for labels, line_num = number of row in the am file.
	return LABEL_DEF_ILLEGAL for invalid label, LABEL_EXISTS otherwise */  
int is_valid_label_exists(char* label, Main_file* file_struct, int label_length, char** invalid_name_label, int line_num) {
	int i, j;
	/* label should start with a letter */    
    if (!isalpha(label[0])) { 
        fprintf(stderr, "Label name should start with a letter. '%s' is an illegal label, line: %d\n", label, line_num);
		file_struct->is_valid_file = NOT_VALID_FILE;
		return LABEL_DEF_ILLEGAL;
	}
	

	/* label should include only numbers and letter */
	if (label_length <= MAX_LABEL_LENGTH)  {
	    for (i = 0; i < label_length; i++) {
	        if (!isalnum(label[i])) {
		        fprintf(stderr, "Label definition '%s' includes characters"\
				      " other than numbers or letters, line: %d\n", label, line_num); 
		        file_struct->is_valid_file = NOT_VALID_FILE;
		        return LABEL_DEF_ILLEGAL;     
		    }
		 }
	} else {   /* label size is bigger than MAX_LABEL_LENGTH */
		fprintf(stderr, "Label '%s' is too big, should be up to " \
			"%d characters, line: %d\n", label, MAX_LABEL_LENGTH, line_num);
		file_struct->is_valid_file = NOT_VALID_FILE;	
		return LABEL_DEF_ILLEGAL;		 
	} 
	
	/*label name can't be a saved name that is a part of the architecture*/
	for (j = 0; j < SAVED_NAMES; j++) {
	    if (strcmp(invalid_name_label[j], label) == 0) {
		    fprintf(stderr, "Label '%s' is a saved word in the " \
		    "computer and can't be used as a label name, line: %d\n" ,label, line_num);
			file_struct->is_valid_file = NOT_VALID_FILE;
			return LABEL_DEF_ILLEGAL;
		}
	}
	return LABEL_EXISTS;
}  
   
/* Check if label exists by searching for column character, if label exists, check its validation (update 'label' value)  
	PARAMETERS: line = instruction, label = a string that the label in the line will be copied to, file_struct = file's data and status,
	invalid_name_label = list for saved words forbidden for labels, line_num = number of row in the am file.
	return LABEL_DEF_ILLEGAL for invalid label, LABEL_EXISTS for label that is exists and valid, NO_LABEL otherwise */    	
int is_label_def_exists(char* line, char* label, Main_file* file_struct, char** invalid_name_label, int line_num) {
    char* column_position = strchr(line, ':');
    int label_length;
    char char_before_column; /* last character in label */
    int i;
	
    /* each label definition should end with column. */
    if (column_position != NULL) {  /* first word is a label */ 
     
		/* label shouldn't end with space character */ 
		char_before_column = *(column_position - 1); 
		if (char_before_column == ' ') { /*found invalid space before column*/
	       fprintf(stderr, "Label shouldn't end with a space, line: %d\n", line_num);
		   file_struct->is_valid_file = NOT_VALID_FILE;
		   return LABEL_DEF_ILLEGAL;
		}
		
		/* reads the label until the first column character */
		label_length = column_position - line; 
		if (label_length <= MAX_LABEL_LENGTH) {
			for (i = 0; i < label_length; i++) {
					label[i] = line[i]; 
			}
			label[i] = '\0';			
		} else {
				fprintf(stderr, "Label definition is too big, should be up to " \
				"%d characters, line: %d\n", MAX_LABEL_LENGTH, line_num);
				file_struct->is_valid_file = NOT_VALID_FILE;
		   		return LABEL_DEF_ILLEGAL;
		}
			
		return is_valid_label_exists(label, file_struct, label_length, invalid_name_label, line_num);
	}
    return NO_LABEL;
}
 
	  	
