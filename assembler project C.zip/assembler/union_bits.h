/*this file was made by Itay Markovitz and Chen Dolev*/

#ifndef UNI_BITS_H
#define UNI_BITS_H

/*for printing in base64*/
typedef struct six_six_bits{
	unsigned int right_six:6;
	unsigned int left_six:6;
}Six_six_bits;
/*for regular instruction line*/ 
typedef struct instruction_line{
	unsigned int pad:2;
	unsigned int target:3;
	unsigned int opcode:4;
	unsigned int source:3;
}Instruction_line;
/*for constant numbers */
typedef struct constant_num_bits{
	unsigned int ARE:2;
	signed int num:10;
}Constant_num_bits;
/*for labels, and different address if needed*/
typedef struct address_bits{
	unsigned int ARE:2;
	unsigned int addr:10;
}Address_bits;
/*constants, .data and .string content*/
typedef struct value_bits{
	signed int value:12;
} Value_bits;
/*if there is 2 registers int the command line*/
typedef struct reg_reg_bits{
	unsigned int ARE:2;
	unsigned int target:5;
	unsigned int source:5;
} Reg_reg_bits;
/*if there is register as target in the command line*/


/*hold all the structs above, is the general "word" for the program*/
typedef union word{
	Six_six_bits six_six;
	Instruction_line inst_ln;
	Constant_num_bits const_num;
	Address_bits addr_bit;
	Value_bits val_bit;
	Reg_reg_bits reg_reg;
} Word;

#endif
