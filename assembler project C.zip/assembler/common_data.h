/*this file was made by Itay Markovitz and Chen Dolev*/
#ifndef COMMON_DATA_H
#define COMMON_DATA_H

/* This file contains all shared data between syntax analyze files: syntax.c, instruction_analyze.c,
	and directive_analyze.c */
	
#define OPERATION_NUM 16  /*number available operations */
#define REGISTER_NUM 8  /* number available registers */

/* names that are in use as part of the computer architecture and can't be label/macro name */
#define SAVED_NAMES 20 

/* status of consecutive commas in instruction/directive lines */
#define CONSECUTIVE_COMMAS 0
#define NO_CONSECUTIVE_COMMAS 1


#define MAX_LABEL_LENGTH 31 /* max length of label definition */
#define MAX_LINE_LENGTH 80 /* max length of each line that is read from file*/

#define DIRECTIVE 1 /* classify line as directive (define type.extern, .entry, .string, .data) */
#define INSTRUCTION 0  /* classify line as instruction (operate operation) */

/* minimun and maximun numbers that can be saved by 10 bits (constant variables in instructions) */ 
#define MIN_NUM_10 -512 
#define MAX_NUM_10 511

/* minimun and maximun numbers that can be saved by 12 bits (for defining .data and .string types)*/ 
#define MIN_NUM_12 -2048  
#define MAX_NUM_12 2047

/* printable ASCII characters range */
#define SPACE_ASCII 32
#define TILDE_ASCII 126

#define MISSING_COMMA 0 /* at least one missing comma between parameters */
#define NO_MISSING_COMMA 1 /* no missing comma between parameters */

#define BAD_PARAM 0 /* param is illegal or doesn't fit to the operation */
#define GOOD_PARAM 1 /* param is legal and fits to the operation */
#define ADDRESSING_METHODS 3  /* classify parameters of operations */

/* Addressing methods for parameters of operations */
enum ParametersType {
    NUM = 1, /* parameter is a constant integer */
    LABEL = 3,  /* parameter is label (external/internal) */ 
    REG = 5, /* parameter is register */
    ILLEGAL_PARAM = -1,  /* unknown parameter */
    END_ARR = -2
};

/* defining operation */
struct operation_data {
    const char* opcode_name;  /* operation's name */
    const int param_number; /* parameters number of the operation*/
    /* addressing methods of parameters
    N = number, L = label, R = register, NULL = doesn't exists */
    const int source[ADDRESSING_METHODS+1];  /* first parameter */
    const int target[ADDRESSING_METHODS+1];  /* second parameter/single parameter in operation */
};

/* initialize and return the 'operations' array */
struct operation_data* get_operations_array(void);

/* initialize and return the 'invalid_name_label' array */
char** get_invalid_name_label_array(void);



#endif
