/*this file was made by Itay Markovitz and Chen Dolev*/
#ifndef SYNTAX_H
#define SYNTAX_H

#include "main.h"
#include "common_data.h"
#include <ctype.h>

/* check if there are missing commas between parameters in instruction/directive line (at least one comma is missing) */
void is_missing_comma_parameters(char* line, int* parameter_counter, int* missing_comma, int line_num);

/* check if there is a memory leak by checking if the sum of the instruction counter + directive counter less than MEMORY_SIZE_MAX - START_ADDRESS */
int is_memory_leak(int required_IC, int required_DC,  Main_file* file_struct, int line_num);

/* Check if the current line has valid syntax by analyzing its type and the line accordingly */
int is_syntax_valid(char* line, Main_file* file_struct , int line_num);

/* get directive definition, analyze its directive type and its parameters */
int is_directive_valid(char* line, char* label, Main_file* file_struct, char** invalid_name_label, int line_num);

/* check if instruction line is valid - valid operation, valid parameters that match the operation, no invalid commas. */
int is_instruction_valid(char* line, char* label, Main_file* file_struct,\
		struct operation_data* operations, char** invalid_name_label, int line_num);

/* erase extra spaces from the line or the parameter - leading and trailing spaces, converts to one space if there is more than one space in a row */
void erase_extra_spaces(char* line_or_param);

/* Check if the current line has extra characters than expected - syntax error */
int check_extra_characters(char* line, Main_file* file_struct, int line_num);	

/* Check if the current parameter is a valid number between min_value to max_value, save its value if valid */			 
int num_param_validation(char* param, int *param_num_value, Main_file* file_struct, int line_num, int min_value, int max_value); 

/* Insert current label to the symbols table if it does not exist in the symbol table, if it already exists - error */
int insert_label_if_new(char* line, char* label, Main_file* file_struct, int line_num, int label_type, int IC, int DC, int status);

/* Check if the current label is valid and all its necessary features are exists */
int is_valid_label_exists(char* label, Main_file* file_struct, int label_length, char** invalid_name_label, int line_num);

/* Check if label exists by searching for column character, if label exists, check its validation (update 'label' value)  */
int is_label_def_exists(char* line, char* label, Main_file* file_struct, char** invalid_name_label, int line_num);	

/* Check if the current string is integer by checking each character. */
int is_integer(char* string);


#endif
